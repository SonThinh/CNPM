﻿namespace QuanLyThiTracNghiem
{
    partial class QuanLiDeThi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuanLiDeThi));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.bttk = new System.Windows.Forms.Button();
            this.tbsearch = new System.Windows.Forms.TextBox();
            this.tbtgl1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbma1 = new System.Windows.Forms.TextBox();
            this.lbma = new System.Windows.Forms.Label();
            this.btxoa = new System.Windows.Forms.Button();
            this.btsua = new System.Windows.Forms.Button();
            this.btthem = new System.Windows.Forms.Button();
            this.tbtd1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.gvde = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tbin = new System.Windows.Forms.Button();
            this.Btsearch2 = new System.Windows.Forms.Button();
            this.tbsearch2 = new System.Windows.Forms.TextBox();
            this.tbmade2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbdethi2 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gvcauhoi = new System.Windows.Forms.DataGridView();
            this.tbsocauhoi2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.thêm = new System.Windows.Forms.Button();
            this.chinhsua = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvde)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvcauhoi)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(960, 711);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Click += new System.EventHandler(this.tabControl1_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.bttk);
            this.tabPage1.Controls.Add(this.tbsearch);
            this.tabPage1.Controls.Add(this.tbtgl1);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.tbma1);
            this.tabPage1.Controls.Add(this.lbma);
            this.tabPage1.Controls.Add(this.btxoa);
            this.tabPage1.Controls.Add(this.btsua);
            this.tabPage1.Controls.Add(this.btthem);
            this.tabPage1.Controls.Add(this.tbtd1);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.textBox6);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(952, 685);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Quản lí đề thi";
            // 
            // button5
            // 
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Image = global::QuanLyThiTracNghiem.Properties.Resources.Save_32x32;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button5.Location = new System.Drawing.Point(151, 85);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(74, 39);
            this.button5.TabIndex = 75;
            this.button5.Text = "save";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // bttk
            // 
            this.bttk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttk.FlatAppearance.BorderSize = 0;
            this.bttk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttk.Image = global::QuanLyThiTracNghiem.Properties.Resources.Find;
            this.bttk.Location = new System.Drawing.Point(820, 89);
            this.bttk.Name = "bttk";
            this.bttk.Size = new System.Drawing.Size(37, 30);
            this.bttk.TabIndex = 74;
            this.bttk.UseVisualStyleBackColor = true;
            this.bttk.Click += new System.EventHandler(this.bttk_Click);
            // 
            // tbsearch
            // 
            this.tbsearch.Location = new System.Drawing.Point(508, 95);
            this.tbsearch.Name = "tbsearch";
            this.tbsearch.Size = new System.Drawing.Size(306, 20);
            this.tbsearch.TabIndex = 4;
            // 
            // tbtgl1
            // 
            this.tbtgl1.Location = new System.Drawing.Point(626, 16);
            this.tbtgl1.Name = "tbtgl1";
            this.tbtgl1.Size = new System.Drawing.Size(118, 20);
            this.tbtgl1.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(514, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 16);
            this.label10.TabIndex = 71;
            this.label10.Text = "Thời gian làm:";
            // 
            // tbma1
            // 
            this.tbma1.Location = new System.Drawing.Point(107, 16);
            this.tbma1.Name = "tbma1";
            this.tbma1.ReadOnly = true;
            this.tbma1.Size = new System.Drawing.Size(118, 20);
            this.tbma1.TabIndex = 1;
            // 
            // lbma
            // 
            this.lbma.AutoSize = true;
            this.lbma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbma.Location = new System.Drawing.Point(26, 17);
            this.lbma.Name = "lbma";
            this.lbma.Size = new System.Drawing.Size(75, 16);
            this.lbma.TabIndex = 63;
            this.lbma.Text = "Mã đề thi:";
            // 
            // btxoa
            // 
            this.btxoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btxoa.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btxoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btxoa.Image = global::QuanLyThiTracNghiem.Properties.Resources.Close_2_icon;
            this.btxoa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btxoa.Location = new System.Drawing.Point(387, 85);
            this.btxoa.Name = "btxoa";
            this.btxoa.Size = new System.Drawing.Size(69, 39);
            this.btxoa.TabIndex = 69;
            this.btxoa.Text = "Xóa";
            this.btxoa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btxoa.UseVisualStyleBackColor = true;
            this.btxoa.Click += new System.EventHandler(this.btxoa_Click);
            // 
            // btsua
            // 
            this.btsua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btsua.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btsua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btsua.Image = global::QuanLyThiTracNghiem.Properties.Resources.Edit_32x32;
            this.btsua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btsua.Location = new System.Drawing.Point(271, 85);
            this.btsua.Name = "btsua";
            this.btsua.Size = new System.Drawing.Size(75, 39);
            this.btsua.TabIndex = 68;
            this.btsua.Text = "Sửa";
            this.btsua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btsua.UseVisualStyleBackColor = true;
            this.btsua.Click += new System.EventHandler(this.btsua_Click);
            // 
            // btthem
            // 
            this.btthem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btthem.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btthem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btthem.Image = global::QuanLyThiTracNghiem.Properties.Resources.add_icon;
            this.btthem.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btthem.Location = new System.Drawing.Point(27, 85);
            this.btthem.Name = "btthem";
            this.btthem.Size = new System.Drawing.Size(77, 39);
            this.btthem.TabIndex = 67;
            this.btthem.Text = "Thêm";
            this.btthem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btthem.UseVisualStyleBackColor = true;
            this.btthem.Click += new System.EventHandler(this.btthem_Click);
            // 
            // tbtd1
            // 
            this.tbtd1.Location = new System.Drawing.Point(352, 16);
            this.tbtd1.Name = "tbtd1";
            this.tbtd1.Size = new System.Drawing.Size(143, 20);
            this.tbtd1.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(265, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 16);
            this.label11.TabIndex = 64;
            this.label11.Text = "Tên đề thi:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.gvde);
            this.groupBox3.Location = new System.Drawing.Point(4, 141);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(944, 532);
            this.groupBox3.TabIndex = 65;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Bảng danh sách đề";
            // 
            // gvde
            // 
            this.gvde.BackgroundColor = System.Drawing.SystemColors.Window;
            this.gvde.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvde.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gvde.GridColor = System.Drawing.SystemColors.Window;
            this.gvde.Location = new System.Drawing.Point(3, 16);
            this.gvde.Name = "gvde";
            this.gvde.ReadOnly = true;
            this.gvde.RowHeadersWidth = 40;
            this.gvde.Size = new System.Drawing.Size(938, 513);
            this.gvde.TabIndex = 0;
            this.gvde.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvde_CellContentClick);
            this.gvde.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gvde_RowHeaderMouseClick);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(232, 637);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(97, 39);
            this.button3.TabIndex = 44;
            this.button3.Text = "Xóa";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 637);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 39);
            this.button1.TabIndex = 42;
            this.button1.Text = "Thêm";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(9, 598);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 16);
            this.label9.TabIndex = 41;
            this.label9.Text = "Đáp án đúng";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D"});
            this.comboBox1.Location = new System.Drawing.Point(151, 593);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(178, 21);
            this.comboBox1.TabIndex = 40;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(9, 538);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox6.Size = new System.Drawing.Size(320, 39);
            this.textBox6.TabIndex = 39;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 519);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 16);
            this.label8.TabIndex = 38;
            this.label8.Text = "Đáp án D";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.tabPage2.Controls.Add(this.tbin);
            this.tabPage2.Controls.Add(this.Btsearch2);
            this.tabPage2.Controls.Add(this.tbsearch2);
            this.tabPage2.Controls.Add(this.tbmade2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.cbdethi2);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.tbsocauhoi2);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.thêm);
            this.tabPage2.Controls.Add(this.chinhsua);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(952, 685);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Quản lí câu hỏi";
            // 
            // tbin
            // 
            this.tbin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbin.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.tbin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tbin.ForeColor = System.Drawing.SystemColors.Window;
            this.tbin.Image = global::QuanLyThiTracNghiem.Properties.Resources.print;
            this.tbin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tbin.Location = new System.Drawing.Point(436, 101);
            this.tbin.Name = "tbin";
            this.tbin.Size = new System.Drawing.Size(77, 39);
            this.tbin.TabIndex = 91;
            this.tbin.Text = "In";
            this.tbin.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tbin.UseVisualStyleBackColor = true;
            // 
            // Btsearch2
            // 
            this.Btsearch2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btsearch2.FlatAppearance.BorderSize = 0;
            this.Btsearch2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btsearch2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Btsearch2.Image = global::QuanLyThiTracNghiem.Properties.Resources.Find;
            this.Btsearch2.Location = new System.Drawing.Point(849, 111);
            this.Btsearch2.Name = "Btsearch2";
            this.Btsearch2.Size = new System.Drawing.Size(38, 29);
            this.Btsearch2.TabIndex = 90;
            this.Btsearch2.UseVisualStyleBackColor = true;
            this.Btsearch2.Click += new System.EventHandler(this.Btsearch2_Click);
            // 
            // tbsearch2
            // 
            this.tbsearch2.Location = new System.Drawing.Point(537, 114);
            this.tbsearch2.Name = "tbsearch2";
            this.tbsearch2.Size = new System.Drawing.Size(306, 20);
            this.tbsearch2.TabIndex = 89;
            // 
            // tbmade2
            // 
            this.tbmade2.Location = new System.Drawing.Point(590, 13);
            this.tbmade2.Name = "tbmade2";
            this.tbmade2.ReadOnly = true;
            this.tbmade2.Size = new System.Drawing.Size(51, 20);
            this.tbmade2.TabIndex = 87;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(533, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 16);
            this.label1.TabIndex = 88;
            this.label1.Text = "Mã đề";
            // 
            // cbdethi2
            // 
            this.cbdethi2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbdethi2.FormattingEnabled = true;
            this.cbdethi2.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D"});
            this.cbdethi2.Location = new System.Drawing.Point(62, 12);
            this.cbdethi2.Name = "cbdethi2";
            this.cbdethi2.Size = new System.Drawing.Size(157, 21);
            this.cbdethi2.TabIndex = 76;
            this.cbdethi2.SelectionChangeCommitted += new System.EventHandler(this.cbdethi2_SelectionChangeCommitted);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(29, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 16);
            this.label13.TabIndex = 82;
            this.label13.Text = "Import Excel";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gvcauhoi);
            this.groupBox2.Location = new System.Drawing.Point(3, 151);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(948, 528);
            this.groupBox2.TabIndex = 81;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bảng câu hỏi";
            // 
            // gvcauhoi
            // 
            this.gvcauhoi.BackgroundColor = System.Drawing.SystemColors.Window;
            this.gvcauhoi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvcauhoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gvcauhoi.GridColor = System.Drawing.SystemColors.Window;
            this.gvcauhoi.Location = new System.Drawing.Point(3, 16);
            this.gvcauhoi.Name = "gvcauhoi";
            this.gvcauhoi.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.gvcauhoi.Size = new System.Drawing.Size(942, 509);
            this.gvcauhoi.TabIndex = 0;
            // 
            // tbsocauhoi2
            // 
            this.tbsocauhoi2.Location = new System.Drawing.Point(334, 13);
            this.tbsocauhoi2.Name = "tbsocauhoi2";
            this.tbsocauhoi2.ReadOnly = true;
            this.tbsocauhoi2.Size = new System.Drawing.Size(157, 20);
            this.tbsocauhoi2.TabIndex = 78;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(252, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 16);
            this.label3.TabIndex = 79;
            this.label3.Text = "Số câu hỏi";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 16);
            this.label2.TabIndex = 77;
            this.label2.Text = "Đề";
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.SystemColors.Window;
            this.button4.Image = global::QuanLyThiTracNghiem.Properties.Resources.Close_2_icon;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(305, 101);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(77, 39);
            this.button4.TabIndex = 86;
            this.button4.Text = "Xóa";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // thêm
            // 
            this.thêm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.thêm.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.thêm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.thêm.ForeColor = System.Drawing.SystemColors.Window;
            this.thêm.Image = global::QuanLyThiTracNghiem.Properties.Resources.add_icon;
            this.thêm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.thêm.Location = new System.Drawing.Point(32, 101);
            this.thêm.Name = "thêm";
            this.thêm.Size = new System.Drawing.Size(77, 39);
            this.thêm.TabIndex = 85;
            this.thêm.Text = "Thêm";
            this.thêm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.thêm.UseVisualStyleBackColor = true;
            this.thêm.Click += new System.EventHandler(this.button2_Click);
            // 
            // chinhsua
            // 
            this.chinhsua.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chinhsua.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.chinhsua.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chinhsua.ForeColor = System.Drawing.SystemColors.Window;
            this.chinhsua.Image = global::QuanLyThiTracNghiem.Properties.Resources.Edit_32x32;
            this.chinhsua.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.chinhsua.Location = new System.Drawing.Point(168, 101);
            this.chinhsua.Name = "chinhsua";
            this.chinhsua.Size = new System.Drawing.Size(77, 39);
            this.chinhsua.TabIndex = 84;
            this.chinhsua.Text = "Sửa";
            this.chinhsua.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chinhsua.UseVisualStyleBackColor = true;
            this.chinhsua.Click += new System.EventHandler(this.chinhsua_Click);
            // 
            // button8
            // 
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Image = global::QuanLyThiTracNghiem.Properties.Resources.ms_excel_icon;
            this.button8.Location = new System.Drawing.Point(168, 55);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(77, 35);
            this.button8.TabIndex = 83;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // QuanLiDeThi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 711);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "QuanLiDeThi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QuanLiDeThi";
            this.Load += new System.EventHandler(this.QuanLiDeThi_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gvde)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gvcauhoi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox tbtgl1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbma1;
        private System.Windows.Forms.Label lbma;
        private System.Windows.Forms.Button btxoa;
        private System.Windows.Forms.Button btsua;
        private System.Windows.Forms.Button btthem;
        private System.Windows.Forms.TextBox tbtd1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView gvde;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button chinhsua;
        private System.Windows.Forms.ComboBox cbdethi2;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView gvcauhoi;
        private System.Windows.Forms.TextBox tbsocauhoi2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bttk;
        private System.Windows.Forms.TextBox tbsearch;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button thêm;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox tbmade2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Btsearch2;
        private System.Windows.Forms.TextBox tbsearch2;
        private System.Windows.Forms.Button tbin;
    }
}