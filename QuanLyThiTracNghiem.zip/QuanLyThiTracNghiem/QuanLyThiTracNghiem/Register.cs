﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    public partial class Register : Form
    {
        AccessDB AccessDB;
        public Register()
        {
            InitializeComponent();
            //set cb ngay thang nam
            for (int i = 1; i <= 31; i++)
            {
                this.cbDate.Items.Add(i.ToString());
            }

            for (int i = 1; i <= 12; i++)
            {
                this.cbMonth.Items.Add(i.ToString());
            }

            for (int i = 2018; i >= 1970; i--)
            {
                this.cbYear.Items.Add(i.ToString());
            }
        }

        private bool checkAccount()
        {
            AccessDB = new AccessDB();
            SqlConnection conn = AccessDB.GetConnection();
            SqlCommand cmd = new SqlCommand("select TK from Account where Account.TK ='" + txtUser.Text + "' ", conn);
            conn.Open();
            cmd.CommandType = CommandType.Text;
            object obj = cmd.ExecuteScalar();
            conn.Close();
            if (obj != null)
                return false;
            else
                return true;
        }

        private bool checkUserGV()
        {
            AccessDB = new AccessDB();
            SqlConnection conn = AccessDB.GetConnection();
            SqlCommand cmd = new SqlCommand("select *from GV where GV.Maso ='" + txtMS.Text + "' and GV.Hoten = '" + txtName.Text + "' ", conn);
            conn.Open();
            cmd.CommandType = CommandType.Text;
            object obj = cmd.ExecuteScalar();
            conn.Close();
            if (obj != null)
                return false;
            else
                return true;
        }

        private bool checkUserSV()
        {
            AccessDB = new AccessDB();
            SqlConnection conn = AccessDB.GetConnection();
            SqlCommand cmd = new SqlCommand("select *from SV where SV.Maso ='" + txtMS.Text + "' and SV.Hoten = '" + txtName.Text + "' ", conn);
            conn.Open();
            cmd.CommandType = CommandType.Text;
            object obj = cmd.ExecuteScalar();
            conn.Close();
            if (obj != null)
                return false;
            else
                return true;
        }

        private void btRegist_Click(object sender, EventArgs e)
        {
            if (txtPass2.Text != txtPass1.Text)
            {
                MessageBox.Show("Mật khẩu xác nhận không chính xác!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            AccessDB = new AccessDB();

            checkDateTime t = new checkDateTime();
            if (t.KiemTraHopLe(cbDate, cbMonth, cbYear) == 1)
            {
                string Gender = "";
                if (male.Checked == true)
                {
                    Gender = "Nam";
                }
                else if (female.Checked == true)
                {
                    Gender = "Nữ";
                }

                String birth = "";
                birth = cbMonth.SelectedItem.ToString() + "/" + cbDate.SelectedItem.ToString() + "/" + cbYear.SelectedItem.ToString();
                if (checkAccount())
                {
                    if (checkUserGV())
                    {
                        if (checkUserSV())
                        {
                            if (ckGV.Checked == true)
                            {
                                AccessDB.GetConnection();
                                string q = "GV";
                                string gv = "Insert into Account values('" + txtUser.Text + "','" + txtPass1.Text + "','" + q + "')";
                                AccessDB.ExcuteNonQuery(gv);
                                AccessDB.GetConnection();
                                string gv1 = "Insert into GV values('" + txtMS.Text + "', N'" + txtName.Text + "','" + txtEmail.Text + "','" + cbSub.Text + "', N'" + Gender + "','" + birth + "','" + txtUser.Text + "')";
                                AccessDB.ExcuteNonQuery(gv1);
                                MessageBox.Show("Đăng Ký Thành Công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.Close();
                            }
                            else if (ckSV.Checked == true)
                            {
                                AccessDB.GetConnection();
                                string q = "SV";
                                string sv = "Insert into Account values('" + txtUser.Text + "','" + txtPass1.Text + "','" + q + "')";
                                AccessDB.ExcuteNonQuery(sv);
                                AccessDB.GetConnection();
                                string sv1 = "Insert into SV values('" + txtMS.Text + "', N'" + txtName.Text + "','" + txtEmail.Text + "','" + cbSub.Text + "', N'" + Gender + "','" + birth + "','" + txtUser.Text + "')";
                                AccessDB.ExcuteNonQuery(sv1);
                                MessageBox.Show("Đăng Ký Thành Công", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.Close();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Người dùng đã tồn tại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Người dùng đã tồn tại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Tài khoản đã tồn tại", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                cbDate.Text = "Date:";
                cbMonth.Text = "Month:";
                cbYear.Text = "Year:";
            }

        }

        private void btOut_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }
    }
}
