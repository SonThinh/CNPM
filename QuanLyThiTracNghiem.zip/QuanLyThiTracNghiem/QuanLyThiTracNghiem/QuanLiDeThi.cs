﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace QuanLyThiTracNghiem
{
    public partial class QuanLiDeThi : Form
    {

        public static string ttde = null;
        public QuanLiDeThi()
        {
            InitializeComponent();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            new ReadExcel().Read(null);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string input = Interaction.InputBox("Nhập tên đề", "Thêm đề mới", "Default", -1, -1);
        }

        private void QuanLiDeThi_Load(object sender, EventArgs e)
        {
            AccessDB.accessDB = new AccessDB();
            LoadThongTinCauHoi();
            LoadGridViewDe();
        }
        public void LoadThongTinCauHoi()
        {
            string sql = "select * from DeThi";
            cbdethi2.DataSource = AccessDB.accessDB.FillDataAdapter(sql).Tables[0];
            cbdethi2.DisplayMember = "Tende";
            cbdethi2.ValueMember = "Made";

        }
        public void LoadGridViewDe()
        {
            string sql = "select made as 'Mã',tende as 'Tên đề', thoigianlam as 'Thời gian làm', socau as 'Số câu hỏi' from DeThi";
            gvde.DataSource = AccessDB.accessDB.FillDataAdapter(sql).Tables[0];
            for (int i = 0; i < gvde.ColumnCount; i++)
            {
                gvde.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            gvde.Columns[3].ReadOnly= true;
        }
        public void LoadGridViewCauhoi(string dk)
        {
            string sql = "select Macauhoi, Made as N'Mã Đề',Noidung as N'Nội dung', DAA as 'A', DAB as 'B' , DAC as 'C', DAD as 'D', DADung as N'Đáp Án' from CTCauhoi where Made = '" + cbdethi2.SelectedValue+"' and noidung like '"+dk+"'";
            gvcauhoi.DataSource = AccessDB.accessDB.FillDataAdapter(sql).Tables[0];
            gvcauhoi.Columns[2].Width = 400;
            for (int i=0; i < gvcauhoi.ColumnCount; i++)
            {
                if(i!= 2) gvcauhoi.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            gvcauhoi.Columns[0].Visible = false;
            string s = "select count(c.Noidung) from CTCauhoi c where c.Made = '" + cbdethi2.SelectedValue + "'";
            int a = AccessDB.accessDB.ExecuteScalar(s);
            tbsocauhoi2.Text = a + "";
            try
            {
                tbmade2.Text = cbdethi2.SelectedValue.ToString();
            }
            catch { tbmade2.Text = null; }
        }

        private void btthem_Click(object sender, EventArgs e)
        {
            tbtd1.Focus();
            clear();
            try
            {
                string s = "select top 1 RIGHT(Made, 3) from Dethi group by Made order by Made desc";
                int a = Int32.Parse(AccessDB.accessDB.ExecuteScalarS(s));
                a++;
                if (a >= 100)
                    s = "TA" + a;
                else if (a >= 10)
                    s = "TA0" + a;
                else
                    s = "TA00" + a;
                tbma1.Text = s;
            }
            catch
            {
                tbma1.Text = "TA001";
            }
        }

        private void btsua_Click(object sender, EventArgs e)
        {
            if (tbma1.Text == "" || tbtd1.Text == "" || tbtgl1.Text == "")
            {
                MessageBox.Show("Bạn chưa chọn dòng để chĩnh sửa!");
            }
            else { 
                string sql = "update Dethi set Tende = N'"+tbtd1.Text+"', thoigianlam = "+tbtgl1.Text+" where made = '"+tbma1.Text+"'";
                int a = AccessDB.accessDB.ExcuteNonQuery(sql);
                if (a > 0)
                {
                    MessageBox.Show("Updated");
                    LoadGridViewDe();
                }
            }
        }

        private void btxoa_Click(object sender, EventArgs e)
        {
            int a = gvde.SelectedRows.Count;
                if (a<1)
                {
                    MessageBox.Show("Bạn chưa chọn dòng để xóa!");
                }
                else
                {
                    try
                    {
                    string mac = null;
                    for (int i = 0; i < a; i++)
                    {
                        if (i == (a - 1))
                        {
                            mac = mac + "Made = '" + gvde.SelectedRows[i].Cells[0].Value.ToString()+"'";
                        }
                        else mac = mac + "Made = '" + gvde.SelectedRows[i].Cells[0].Value.ToString() + "'" + " or ";
                    }
                    string sql = "delete from ketqua where " + mac;
                    string l = ((a > 1) ? a.ToString() : "");
                        DialogResult dr = MessageBox.Show("Bạn có chắc sẽ xóa "+ l +" dòng này!", "Delete", MessageBoxButtons.YesNo);
                        switch (dr)
                        {
                            case DialogResult.Yes:
                                AccessDB.accessDB.ExcuteNonQuery(sql);
                                sql = "delete from CTCauhoi where " + mac;
                                AccessDB.accessDB.ExcuteNonQuery(sql);
                                sql = "delete from Dethi where "+ mac;
                                AccessDB.accessDB.ExcuteNonQuery(sql);
                                tbma1.Text = null;
                                tbtd1.Text = null;
                                tbtgl1.Text = null;
                                MessageBox.Show("Deleted");
                                LoadGridViewDe();
                                break;
                            case DialogResult.No:
                                break;
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Lỗi");
                    }
                }
        }
        public Boolean kiemtradinhdangdethi()
        {
            if (tbma1.Text == "" || tbtd1.Text == "" || tbtgl1.Text == "")
            {
                MessageBox.Show("Bạn chưa điền đủ thông tin!");
                return false;
            }
            int n;
            if (int.TryParse(tbtgl1.Text, out n) == false)
            {
                MessageBox.Show("Error, Thời gian làm bài là số phút!");
                return false;
            }
            return true;
        }
        public void clear ()
        {
            tbma1.Text = "";  tbtd1.Text = ""; tbtgl1.Text = "";
        }


        private void button5_Click(object sender, EventArgs e)
        {
            if (kiemtradinhdangdethi())
            {
                string sql = "select count(*) from Dethi where made ='" + tbma1.Text + "'";
                int kt = AccessDB.accessDB.ExecuteScalar(sql);
                if (kt == 1)
                {
                    MessageBox.Show("Đã tồn tại đề có mã " + tbma1.Text);
                    return;
                }
                sql = "insert into Dethi values('" + tbma1.Text + "', N'" + tbtd1.Text + "'," + tbtgl1.Text + ",0)";
                int a = AccessDB.accessDB.ExcuteNonQuery(sql);
                if (a > 0)
                {
                    MessageBox.Show("Added");
                    LoadGridViewDe();

                    clear();
                }
            }
        }

        private void bttk_Click(object sender, EventArgs e)
        {
            string sql = "select made as 'Mã',tende as 'Tên đề', thoigianlam as 'Thời gian làm', socau as 'Số câu hỏi' from DeThi where made like '" + tbsearch.Text.Trim() + "' or tende like '" + tbsearch.Text.Trim() + "%';";
            gvde.DataSource = AccessDB.accessDB.FillDataAdapter(sql).Tables[0];
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {

            LoadThongTinCauHoi();
            LoadGridViewCauhoi("%");
            LoadGridViewDe();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            try
            {
                string[] ch = new ReadExcel().Read(cbdethi2.SelectedValue + "");
                int a = AccessDB.accessDB.InsertDataAdapter("select * from CTCauhoi;", "Noidung_DAA_DAB_DAC_DAD_DADung_Made", ch);
                if (a > 0) MessageBox.Show("Đã thêm " + a + " câu hỏi vào đề " + cbdethi2.Text);
                LoadGridViewCauhoi("%");
            }
            catch { }
        }
        
        private void cbdethi2_SelectionChangeCommitted(object sender, EventArgs e)
        {
            LoadGridViewCauhoi("%");
        }

        private void gvde_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                int rowIndex = Convert.ToInt32(e.RowIndex);
                tbma1.Text = "" + (gvde.Rows[rowIndex].Cells[0].Value);
                tbtd1.Text = "" + (gvde.Rows[rowIndex].Cells[1].Value);
                tbtgl1.Text = "" + (gvde.Rows[rowIndex].Cells[2].Value);
                int a = gvde.SelectedRows.Count;
            }
            catch (Exception)
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            ttde = cbdethi2.SelectedValue + " " + tbsocauhoi2.Text+" "+tbmade2.Text + " ";
            new ChinhSuaThongTinCauHoi("t").ShowDialog();
            LoadGridViewCauhoi("%");
            this.Show();
        }

        private void chinhsua_Click(object sender, EventArgs e)
        {
            int a = gvcauhoi.SelectedRows.Count;
            if (a == 0)
            {
                MessageBox.Show("Ban chưa chọn dòng để chỉnh sửa!");
                return;
            }
            ttde = cbdethi2.SelectedValue + " " + tbsocauhoi2.Text + " " + tbmade2.Text +" "+ gvcauhoi.SelectedCells[0].Value.ToString();
            this.Hide();
            new ChinhSuaThongTinCauHoi("c").ShowDialog();
            LoadGridViewCauhoi("%");
            this.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int a = gvcauhoi.SelectedRows.Count;
            if (a == 0)
            {
                MessageBox.Show("Ban chưa chọn dòng xóa!");
                return;
            }
            try
            {
                string c = (a>1) ? a.ToString(): "";
                DialogResult dr = MessageBox.Show("Bạn có chắc sẽ xóa "+ c + " dòng này!", "Delete", MessageBoxButtons.YesNo);
                switch (dr)
                {
                    
                    case DialogResult.Yes:
                        string mac = null;
                        for (int i = 0; i < a; i++)
                        {
                            if (i == (a - 1))
                            {
                                mac = mac + "macauhoi = " + gvcauhoi.SelectedRows[i].Cells[0].Value.ToString();
                            }
                            else mac = mac + "macauhoi = " + gvcauhoi.SelectedRows[i].Cells[0].Value.ToString() + " or ";
                        }
                        string sql = "delete from CTCauhoi where " + mac;
                        int ac = AccessDB.accessDB.ExcuteNonQuery(sql);
                        sql = "update Dethi set Socau = " + (Int32.Parse(tbsocauhoi2.Text)-a) + " where Made = '" + gvcauhoi.SelectedCells[1].Value.ToString() + "'";
                        ac = AccessDB.accessDB.ExcuteNonQuery(sql);
                        MessageBox.Show("Deleted");
                        LoadGridViewCauhoi("%");
                        break;
                    case DialogResult.No:
                        break;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Lỗi");
            }
        }

        private void Btsearch2_Click(object sender, EventArgs e)
        {
            LoadGridViewCauhoi("%"+tbsearch2.Text+"%");
        }

        private void gvde_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
