﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    public partial class GV : Form
    {
        int dangxuat = 0;
        public static User Ugv = null;
        public GV()
        {
            InitializeComponent();
        }

        private void GV_Load(object sender, EventArgs e)
        {
            LayThongTinGV(Login.userTK);
            lbt.Text = Ugv.Ten;
            lbk.Text = Ugv.Khoa;
            lbgt.Text = Ugv.Gioitinh;
            lbns.Text = Ugv.Ngaysinh;
        }
        public void LayThongTinGV(string magv)
        {
            AccessDB d = new AccessDB();
            SqlDataReader reader = d.ExecuteReader("select * from GV where TK = '" + magv + "'");
            while (reader.Read())
            {
                Ugv = new User(reader["Maso"].ToString(), reader["Hoten"].ToString(), reader["Email"].ToString()
                    , reader["Makhoa"].ToString(), reader["gioitinh"].ToString(), reader["ngaysinh"].ToString().Split(' ')[0], reader["TK"].ToString(),"GV");
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            new ChinhSuaThongTinUser("gv").ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            new QuanLiDeThi().ShowDialog();
            this.Show();
        }

        private void GV_FormClosing(object sender, FormClosingEventArgs e)
        {
          if (dangxuat == 0)
            {
                DialogResult dialogResult = MessageBox.Show("Bạn muốn đóng Phần mềm", "Close", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    Program.l.Close();
                }
                else
                {
                    e.Cancel = true;
                }
            }
            else
            {
                Program.l.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dangxuat = 1;
            this.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Hide();
            new BangDiemSV().ShowDialog();
            this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
