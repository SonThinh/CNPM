﻿namespace QuanLyThiTracNghiem
{
    partial class ChinhSuaThongTinCauHoi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChinhSuaThongTinCauHoi));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btclose = new System.Windows.Forms.Button();
            this.tbd = new System.Windows.Forms.TextBox();
            this.tbc = new System.Windows.Forms.TextBox();
            this.tbb = new System.Windows.Forms.TextBox();
            this.btsm = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tba = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbnd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cbda = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbmacau = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btclose);
            this.groupBox1.Controls.Add(this.tbd);
            this.groupBox1.Controls.Add(this.tbc);
            this.groupBox1.Controls.Add(this.tbb);
            this.groupBox1.Controls.Add(this.btsm);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tba);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tbnd);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.cbda);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tbmacau);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Window;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(884, 544);
            this.groupBox1.TabIndex = 81;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chi tiết câu hỏi";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btclose
            // 
            this.btclose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btclose.FlatAppearance.BorderSize = 0;
            this.btclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btclose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btclose.ForeColor = System.Drawing.SystemColors.Window;
            this.btclose.Location = new System.Drawing.Point(180, 499);
            this.btclose.Name = "btclose";
            this.btclose.Size = new System.Drawing.Size(92, 39);
            this.btclose.TabIndex = 59;
            this.btclose.Text = "Close";
            this.btclose.UseVisualStyleBackColor = false;
            this.btclose.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbd
            // 
            this.tbd.BackColor = System.Drawing.SystemColors.Window;
            this.tbd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbd.ForeColor = System.Drawing.SystemColors.MenuText;
            this.tbd.Location = new System.Drawing.Point(79, 361);
            this.tbd.Multiline = true;
            this.tbd.Name = "tbd";
            this.tbd.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbd.Size = new System.Drawing.Size(799, 53);
            this.tbd.TabIndex = 58;
            // 
            // tbc
            // 
            this.tbc.BackColor = System.Drawing.SystemColors.Window;
            this.tbc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbc.ForeColor = System.Drawing.SystemColors.MenuText;
            this.tbc.Location = new System.Drawing.Point(79, 300);
            this.tbc.Multiline = true;
            this.tbc.Name = "tbc";
            this.tbc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbc.Size = new System.Drawing.Size(799, 53);
            this.tbc.TabIndex = 57;
            // 
            // tbb
            // 
            this.tbb.BackColor = System.Drawing.SystemColors.Window;
            this.tbb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbb.ForeColor = System.Drawing.SystemColors.MenuText;
            this.tbb.Location = new System.Drawing.Point(79, 241);
            this.tbb.Multiline = true;
            this.tbb.Name = "tbb";
            this.tbb.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbb.Size = new System.Drawing.Size(799, 53);
            this.tbb.TabIndex = 56;
            // 
            // btsm
            // 
            this.btsm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btsm.FlatAppearance.BorderSize = 0;
            this.btsm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btsm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btsm.ForeColor = System.Drawing.SystemColors.Window;
            this.btsm.Location = new System.Drawing.Point(79, 499);
            this.btsm.Name = "btsm";
            this.btsm.Size = new System.Drawing.Size(92, 39);
            this.btsm.TabIndex = 55;
            this.btsm.Text = "Save";
            this.btsm.UseVisualStyleBackColor = false;
            this.btsm.Click += new System.EventHandler(this.button4_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.Window;
            this.label14.Location = new System.Drawing.Point(3, 379);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(72, 16);
            this.label14.TabIndex = 53;
            this.label14.Text = "Đáp án D";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Window;
            this.label7.Location = new System.Drawing.Point(4, 319);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 16);
            this.label7.TabIndex = 36;
            this.label7.Text = "Đáp án C";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(3, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 16);
            this.label6.TabIndex = 34;
            this.label6.Text = "Đáp án B";
            // 
            // tba
            // 
            this.tba.BackColor = System.Drawing.SystemColors.Window;
            this.tba.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tba.ForeColor = System.Drawing.SystemColors.MenuText;
            this.tba.Location = new System.Drawing.Point(79, 182);
            this.tba.Multiline = true;
            this.tba.Name = "tba";
            this.tba.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tba.Size = new System.Drawing.Size(799, 53);
            this.tba.TabIndex = 33;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(3, 204);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 16);
            this.label5.TabIndex = 32;
            this.label5.Text = "Đáp án A";
            // 
            // tbnd
            // 
            this.tbnd.BackColor = System.Drawing.SystemColors.Window;
            this.tbnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbnd.ForeColor = System.Drawing.SystemColors.MenuText;
            this.tbnd.Location = new System.Drawing.Point(79, 64);
            this.tbnd.Multiline = true;
            this.tbnd.Name = "tbnd";
            this.tbnd.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbnd.Size = new System.Drawing.Size(799, 112);
            this.tbnd.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(3, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 16);
            this.label4.TabIndex = 30;
            this.label4.Text = "Nội dung";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 445);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(95, 16);
            this.label12.TabIndex = 52;
            this.label12.Text = "Đáp án đúng";
            // 
            // cbda
            // 
            this.cbda.DisplayMember = "A";
            this.cbda.DropDownHeight = 200;
            this.cbda.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbda.DropDownWidth = 300;
            this.cbda.ForeColor = System.Drawing.SystemColors.MenuText;
            this.cbda.FormattingEnabled = true;
            this.cbda.IntegralHeight = false;
            this.cbda.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D"});
            this.cbda.Location = new System.Drawing.Point(119, 444);
            this.cbda.Name = "cbda";
            this.cbda.Size = new System.Drawing.Size(153, 21);
            this.cbda.TabIndex = 51;
            this.cbda.SelectedIndexChanged += new System.EventHandler(this.cbda_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(6, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 16);
            this.label1.TabIndex = 29;
            this.label1.Text = "Mã đề";
            // 
            // tbmacau
            // 
            this.tbmacau.BackColor = System.Drawing.SystemColors.Window;
            this.tbmacau.ForeColor = System.Drawing.SystemColors.MenuText;
            this.tbmacau.Location = new System.Drawing.Point(79, 29);
            this.tbmacau.Name = "tbmacau";
            this.tbmacau.ReadOnly = true;
            this.tbmacau.Size = new System.Drawing.Size(58, 20);
            this.tbmacau.TabIndex = 0;
            // 
            // ChinhSuaThongTinCauHoi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.ClientSize = new System.Drawing.Size(908, 566);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ChinhSuaThongTinCauHoi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChinhSuaThongTinCauHoi";
            this.Load += new System.EventHandler(this.ChinhSuaThongTinCauHoi_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btsm;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tba;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbnd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cbda;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbmacau;
        private System.Windows.Forms.TextBox tbd;
        private System.Windows.Forms.TextBox tbc;
        private System.Windows.Forms.TextBox tbb;
        private System.Windows.Forms.Button btclose;
    }
}