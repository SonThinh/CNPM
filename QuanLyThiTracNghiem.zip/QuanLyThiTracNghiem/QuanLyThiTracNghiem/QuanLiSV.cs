﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    public partial class QuanLiSV : Form
    {
        public QuanLiSV()
        {
            InitializeComponent();
        }

        private void load_Click(object sender, EventArgs e)
        {
            Search("%", "%");
        }

        private void QuanLiGV_Load(object sender, EventArgs e)
        {

        }
        public void Search(string dktk, string dkten)
        {

            String sql = "select a.TK, a.MK from Account a, SV g where a.Quyen = 'SV' and (a.TK like '" + dktk + "' or g.Hoten='" + dkten + "') and g.TK = a.TK";
            gvtk.DataSource = AccessDB.accessDB.FillDataAdapter(sql).Tables[0];
            sql = "select g.Maso, g.Hoten, g.Email, g.MaKhoa, g.Gioitinh, g.Ngaysinh , g.TK from SV g, Account where g.TK = Account.TK and (Account.TK like '" + dktk + "' or g.Hoten like '" + dkten + "')";
            GridGV.DataSource = AccessDB.accessDB.FillDataAdapter(sql).Tables[0];
        }
        public int delete()
        {
            try
            {
                if (txtTK.Text == "")
                {
                    MessageBox.Show("Bạn chưa nhập tài khoản");
                }
                else
                {
                    int a;
                    string sql = "delete from SV where TK = '" + txtTK.Text + "'";
                    a = AccessDB.accessDB.ExecuteScalar(sql);
                    sql = "delete from Account where Quyen = 'SV' and TK = '" + txtTK.Text + "'";
                    a = AccessDB.accessDB.ExecuteScalar(sql);
                    return a;
                }
            }
            catch { }
            return 0;
        }

        private void btsearch_Click(object sender, EventArgs e)
        {
            if (txtTK.Text != "" && txtms.Text != "")
            {
                Search(txtTK.Text, txtms.Text);
            }
            else if (txtTK.Text != "")
            {
                Search(txtTK.Text, "");
            }
            else if (txtms.Text != "")
            {
                Search("", txtms.Text);
            }
            else
            {
                Search("%", "%");
            }
        }

        private void btnew_Click(object sender, EventArgs e)
        {
            new Register().Show();
        }

        private void btdelete_Click(object sender, EventArgs e)
        {
            int a = delete();
            if (a == 1 || a == -1)
            {
                MessageBox.Show("Deleted");
            }
        }

        private void QuanLiSV_Load(object sender, EventArgs e)
        {

        }
    }
}
