﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    class ReadExcel
    {
        public string[] cauhoi = null;
        public string[] Read(string val)
        {
            
            string fname = "";
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Excel File Dialog";
            fdlg.InitialDirectory = @"c:\";
            fdlg.Filter = "All files (*.*)|*.*|All files (*.*)|*.*";
            fdlg.FilterIndex = 2;
            fdlg.RestoreDirectory = true;
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                fname = fdlg.FileName;
            }

            try
            {
                Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(fname);
                Microsoft.Office.Interop.Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
                Microsoft.Office.Interop.Excel.Range range = xlWorksheet.UsedRange;
                int rowCount = range.Rows.Count;
                string nd = null;
                string a = null;
                string b = null;
                string c = null;
                string d = null;
                string da = null;
                cauhoi = new string[rowCount];
                for (int i = 1; i <= rowCount; i++)
                {
                    nd = range.Cells[i, 1].Value.ToString();
                    a = range.Cells[i, 2].Value.ToString();
                    b = range.Cells[i, 3].Value.ToString();
                    c = range.Cells[i, 4].Value.ToString();
                    d = range.Cells[i, 5].Value.ToString();
                    da = range.Cells[i, 6].Value.ToString();
                    cauhoi[i-1]= nd + "_" + a + "_"+ b + "_" +c+ "_" +d +"_"+ da+"_"+ val;
                }
                //cleanup  
                GC.Collect();
                GC.WaitForPendingFinalizers();
                Marshal.ReleaseComObject(range);
                Marshal.ReleaseComObject(xlWorksheet);

                //close and release  
                xlWorkbook.Close();
                Marshal.ReleaseComObject(xlWorkbook);

                //quit and release  
                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);
            }
            catch
            {
                MessageBox.Show("Khong doc duoc file!");
            }
            return cauhoi;
        }
    }
}
