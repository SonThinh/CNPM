﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    public partial class BangDiemSV : Form
    {
        public BangDiemSV()
        {
            InitializeComponent();
            Loadcb();
            Load("%");
        }
        public void Load(string dk)
        {
            string sql = "select Makq, SV.Maso as 'Mã số SV' , SV.Hoten as 'Họ và tên', ketqua.diem as 'Điểm', ketqua.NgayThi as 'Ngày thi' from SV, DeThi, ketqua " +
                "where SV.Maso = ketqua.MasoSV and DeThi.Made = ketqua.Made and SV.Hoten like '"+dk+"' and Dethi.Made = '"+ cbdethi.SelectedValue+ "'";
            gvd.DataSource = AccessDB.accessDB.FillDataAdapter(sql).Tables[0];
            gvd.Columns[0].Visible = false;
            for (int i = 1; i < gvd.ColumnCount; i++)
            {
                gvd.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
        }

        public void Loadcb()
        {
            string sql = "select * from DeThi";
            cbdethi.DataSource = AccessDB.accessDB.FillDataAdapter(sql).Tables[0];
            cbdethi.DisplayMember = "Tende";
            cbdethi.ValueMember = "Made";
        }

        private void bttk_Click(object sender, EventArgs e)
        {
            string a = tbsearch.Text + "%";
            Load(a);
        }

        private void cbdethi_SelectedIndexChanged(object sender, EventArgs e)
        {
            Load("%");
        }

        private void tbin_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int a = gvd.SelectedRows.Count;
            if (a == 0)
            {
                MessageBox.Show("Ban chưa chọn dòng xóa!");
                return;
            }
            try
            {
                string c = (a > 1) ? a.ToString() : "";
                DialogResult dr = MessageBox.Show("Bạn có chắc sẽ xóa " + c + " dòng này!", "Delete", MessageBoxButtons.YesNo);
                switch (dr)
                {

                    case DialogResult.Yes:
                        string mac = null;
                        for (int i = 0; i < a; i++)
                        {
                            if (i == (a - 1))
                            {
                                mac = mac + "Makq = " + gvd.SelectedRows[i].Cells[0].Value.ToString();
                            }
                            else mac = mac + "Makq = " + gvd.SelectedRows[i].Cells[0].Value.ToString() + " or ";
                        }
                        string sql = "delete from Ketqua where " + mac;
                        AccessDB.accessDB.ExcuteNonQuery(sql);
                        MessageBox.Show("Deleted");
                        Load("%");
                        break;
                    case DialogResult.No:
                        break;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Lỗi");
            }
        }
    }
}
