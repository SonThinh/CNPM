﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThiTracNghiem
{
    public class Cauhoi
    {
        private int macau;
        private string nd;
        private string a;
        private string b;
        private string c;
        private string d;
        private string da;

        public string Nd { get => nd; set => nd = value; }
        public string A { get => a; set => a = value; }
        public string B { get => b; set => b = value; }
        public string C { get => c; set => c = value; }
        public string D { get => d; set => d = value; }
        public string Da { get => da; set => da = value; }
        public int Macau { get => macau; set => macau = value; }

        public Cauhoi(int macau, string Nd, string A, string B, string C, string D, string Da)
        {
            this.Macau = macau;
            this.Nd = Nd;
            this.A = A;
            this.B = B;
            this.C = C;
            this.D = D;
            this.Da = Da;
        }
        public string toString()
        {
            return macau + nd + a + b + c + d + da;
        }
    }
}
