﻿namespace QuanLyThiTracNghiem
{
    partial class ThiTrucTuyen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThiTrucTuyen));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnext = new System.Windows.Forms.Button();
            this.pnch4 = new System.Windows.Forms.Panel();
            this.lbnd4 = new System.Windows.Forms.TextBox();
            this.l16 = new System.Windows.Forms.Label();
            this.l15 = new System.Windows.Forms.Label();
            this.l14 = new System.Windows.Forms.Label();
            this.l13 = new System.Windows.Forms.Label();
            this.rdD4 = new System.Windows.Forms.RadioButton();
            this.rdC4 = new System.Windows.Forms.RadioButton();
            this.rdB4 = new System.Windows.Forms.RadioButton();
            this.rdA4 = new System.Windows.Forms.RadioButton();
            this.pnch3 = new System.Windows.Forms.Panel();
            this.lbnd3 = new System.Windows.Forms.TextBox();
            this.l12 = new System.Windows.Forms.Label();
            this.l11 = new System.Windows.Forms.Label();
            this.l10 = new System.Windows.Forms.Label();
            this.l9 = new System.Windows.Forms.Label();
            this.rdD3 = new System.Windows.Forms.RadioButton();
            this.rdC3 = new System.Windows.Forms.RadioButton();
            this.rdB3 = new System.Windows.Forms.RadioButton();
            this.rdA3 = new System.Windows.Forms.RadioButton();
            this.pnch2 = new System.Windows.Forms.Panel();
            this.lbnd2 = new System.Windows.Forms.TextBox();
            this.l7 = new System.Windows.Forms.Label();
            this.l8 = new System.Windows.Forms.Label();
            this.l6 = new System.Windows.Forms.Label();
            this.l5 = new System.Windows.Forms.Label();
            this.rdD2 = new System.Windows.Forms.RadioButton();
            this.rdC2 = new System.Windows.Forms.RadioButton();
            this.rdB2 = new System.Windows.Forms.RadioButton();
            this.rdA2 = new System.Windows.Forms.RadioButton();
            this.pnch1 = new System.Windows.Forms.Panel();
            this.btct = new System.Windows.Forms.Button();
            this.lbend = new System.Windows.Forms.Label();
            this.lbnd1 = new System.Windows.Forms.TextBox();
            this.l3 = new System.Windows.Forms.Label();
            this.l4 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.l1 = new System.Windows.Forms.Label();
            this.rdD1 = new System.Windows.Forms.RadioButton();
            this.rdC1 = new System.Windows.Forms.RadioButton();
            this.rdB1 = new System.Windows.Forms.RadioButton();
            this.rdA1 = new System.Windows.Forms.RadioButton();
            this.btend = new System.Windows.Forms.Button();
            this.lbcau = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbtime = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lbde = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lbtg = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbten = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.pnch4.SuspendLayout();
            this.pnch3.SuspendLayout();
            this.pnch2.SuspendLayout();
            this.pnch1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightGray;
            this.groupBox1.Controls.Add(this.btnext);
            this.groupBox1.Controls.Add(this.pnch4);
            this.groupBox1.Controls.Add(this.pnch3);
            this.groupBox1.Controls.Add(this.pnch2);
            this.groupBox1.Controls.Add(this.pnch1);
            this.groupBox1.Location = new System.Drawing.Point(223, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(725, 687);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Câu hỏi";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnext
            // 
            this.btnext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.btnext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnext.ForeColor = System.Drawing.SystemColors.Window;
            this.btnext.Location = new System.Drawing.Point(614, 650);
            this.btnext.Name = "btnext";
            this.btnext.Size = new System.Drawing.Size(105, 31);
            this.btnext.TabIndex = 5;
            this.btnext.Text = "Next";
            this.btnext.UseVisualStyleBackColor = false;
            this.btnext.Click += new System.EventHandler(this.btnext_Click);
            // 
            // pnch4
            // 
            this.pnch4.Controls.Add(this.lbnd4);
            this.pnch4.Controls.Add(this.l16);
            this.pnch4.Controls.Add(this.l15);
            this.pnch4.Controls.Add(this.l14);
            this.pnch4.Controls.Add(this.l13);
            this.pnch4.Controls.Add(this.rdD4);
            this.pnch4.Controls.Add(this.rdC4);
            this.pnch4.Controls.Add(this.rdB4);
            this.pnch4.Controls.Add(this.rdA4);
            this.pnch4.Location = new System.Drawing.Point(20, 478);
            this.pnch4.Name = "pnch4";
            this.pnch4.Size = new System.Drawing.Size(699, 140);
            this.pnch4.TabIndex = 4;
            // 
            // lbnd4
            // 
            this.lbnd4.BackColor = System.Drawing.Color.LightGray;
            this.lbnd4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbnd4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnd4.Location = new System.Drawing.Point(0, 17);
            this.lbnd4.Multiline = true;
            this.lbnd4.Name = "lbnd4";
            this.lbnd4.Size = new System.Drawing.Size(705, 41);
            this.lbnd4.TabIndex = 17;
            // 
            // l16
            // 
            this.l16.AutoSize = true;
            this.l16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l16.Location = new System.Drawing.Point(350, 111);
            this.l16.Name = "l16";
            this.l16.Size = new System.Drawing.Size(21, 20);
            this.l16.TabIndex = 10;
            this.l16.Text = "D";
            // 
            // l15
            // 
            this.l15.AutoSize = true;
            this.l15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l15.Location = new System.Drawing.Point(11, 111);
            this.l15.Name = "l15";
            this.l15.Size = new System.Drawing.Size(20, 20);
            this.l15.TabIndex = 9;
            this.l15.Text = "C";
            // 
            // l14
            // 
            this.l14.AutoSize = true;
            this.l14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l14.Location = new System.Drawing.Point(350, 61);
            this.l14.Name = "l14";
            this.l14.Size = new System.Drawing.Size(20, 20);
            this.l14.TabIndex = 7;
            this.l14.Text = "B";
            // 
            // l13
            // 
            this.l13.AutoSize = true;
            this.l13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l13.Location = new System.Drawing.Point(10, 61);
            this.l13.Name = "l13";
            this.l13.Size = new System.Drawing.Size(20, 20);
            this.l13.TabIndex = 6;
            this.l13.Text = "A";
            // 
            // rdD4
            // 
            this.rdD4.AutoSize = true;
            this.rdD4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdD4.Location = new System.Drawing.Point(376, 111);
            this.rdD4.Name = "rdD4";
            this.rdD4.Size = new System.Drawing.Size(83, 20);
            this.rdD4.TabIndex = 4;
            this.rdD4.TabStop = true;
            this.rdD4.Text = "Đáp Án D";
            this.rdD4.UseVisualStyleBackColor = true;
            // 
            // rdC4
            // 
            this.rdC4.AutoSize = true;
            this.rdC4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdC4.Location = new System.Drawing.Point(36, 111);
            this.rdC4.Name = "rdC4";
            this.rdC4.Size = new System.Drawing.Size(82, 20);
            this.rdC4.TabIndex = 3;
            this.rdC4.TabStop = true;
            this.rdC4.Text = "Đáp Án C";
            this.rdC4.UseVisualStyleBackColor = true;
            // 
            // rdB4
            // 
            this.rdB4.AutoSize = true;
            this.rdB4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdB4.Location = new System.Drawing.Point(376, 61);
            this.rdB4.Name = "rdB4";
            this.rdB4.Size = new System.Drawing.Size(82, 20);
            this.rdB4.TabIndex = 2;
            this.rdB4.TabStop = true;
            this.rdB4.Text = "Đáp Án B";
            this.rdB4.UseVisualStyleBackColor = true;
            // 
            // rdA4
            // 
            this.rdA4.AutoSize = true;
            this.rdA4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdA4.Location = new System.Drawing.Point(36, 61);
            this.rdA4.Name = "rdA4";
            this.rdA4.Size = new System.Drawing.Size(82, 20);
            this.rdA4.TabIndex = 1;
            this.rdA4.TabStop = true;
            this.rdA4.Text = "Đáp Án A";
            this.rdA4.UseVisualStyleBackColor = true;
            // 
            // pnch3
            // 
            this.pnch3.Controls.Add(this.lbnd3);
            this.pnch3.Controls.Add(this.l12);
            this.pnch3.Controls.Add(this.l11);
            this.pnch3.Controls.Add(this.l10);
            this.pnch3.Controls.Add(this.l9);
            this.pnch3.Controls.Add(this.rdD3);
            this.pnch3.Controls.Add(this.rdC3);
            this.pnch3.Controls.Add(this.rdB3);
            this.pnch3.Controls.Add(this.rdA3);
            this.pnch3.Location = new System.Drawing.Point(20, 339);
            this.pnch3.Name = "pnch3";
            this.pnch3.Size = new System.Drawing.Size(699, 133);
            this.pnch3.TabIndex = 3;
            // 
            // lbnd3
            // 
            this.lbnd3.BackColor = System.Drawing.Color.LightGray;
            this.lbnd3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbnd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnd3.Location = new System.Drawing.Point(0, 0);
            this.lbnd3.Multiline = true;
            this.lbnd3.Name = "lbnd3";
            this.lbnd3.Size = new System.Drawing.Size(705, 41);
            this.lbnd3.TabIndex = 16;
            // 
            // l12
            // 
            this.l12.AutoSize = true;
            this.l12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l12.Location = new System.Drawing.Point(350, 100);
            this.l12.Name = "l12";
            this.l12.Size = new System.Drawing.Size(21, 20);
            this.l12.TabIndex = 14;
            this.l12.Text = "D";
            // 
            // l11
            // 
            this.l11.AutoSize = true;
            this.l11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l11.Location = new System.Drawing.Point(11, 100);
            this.l11.Name = "l11";
            this.l11.Size = new System.Drawing.Size(20, 20);
            this.l11.TabIndex = 13;
            this.l11.Text = "C";
            // 
            // l10
            // 
            this.l10.AutoSize = true;
            this.l10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l10.Location = new System.Drawing.Point(350, 50);
            this.l10.Name = "l10";
            this.l10.Size = new System.Drawing.Size(20, 20);
            this.l10.TabIndex = 11;
            this.l10.Text = "B";
            // 
            // l9
            // 
            this.l9.AutoSize = true;
            this.l9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l9.Location = new System.Drawing.Point(10, 50);
            this.l9.Name = "l9";
            this.l9.Size = new System.Drawing.Size(20, 20);
            this.l9.TabIndex = 10;
            this.l9.Text = "A";
            // 
            // rdD3
            // 
            this.rdD3.AutoSize = true;
            this.rdD3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdD3.Location = new System.Drawing.Point(376, 100);
            this.rdD3.Name = "rdD3";
            this.rdD3.Size = new System.Drawing.Size(83, 20);
            this.rdD3.TabIndex = 4;
            this.rdD3.TabStop = true;
            this.rdD3.Text = "Đáp Án D";
            this.rdD3.UseVisualStyleBackColor = true;
            // 
            // rdC3
            // 
            this.rdC3.AutoSize = true;
            this.rdC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdC3.Location = new System.Drawing.Point(36, 97);
            this.rdC3.Name = "rdC3";
            this.rdC3.Size = new System.Drawing.Size(82, 20);
            this.rdC3.TabIndex = 3;
            this.rdC3.TabStop = true;
            this.rdC3.Text = "Đáp Án C";
            this.rdC3.UseVisualStyleBackColor = true;
            // 
            // rdB3
            // 
            this.rdB3.AutoSize = true;
            this.rdB3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdB3.Location = new System.Drawing.Point(376, 49);
            this.rdB3.Name = "rdB3";
            this.rdB3.Size = new System.Drawing.Size(82, 20);
            this.rdB3.TabIndex = 2;
            this.rdB3.TabStop = true;
            this.rdB3.Text = "Đáp Án B";
            this.rdB3.UseVisualStyleBackColor = true;
            // 
            // rdA3
            // 
            this.rdA3.AutoSize = true;
            this.rdA3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdA3.Location = new System.Drawing.Point(36, 49);
            this.rdA3.Name = "rdA3";
            this.rdA3.Size = new System.Drawing.Size(82, 20);
            this.rdA3.TabIndex = 1;
            this.rdA3.TabStop = true;
            this.rdA3.Text = "Đáp Án A";
            this.rdA3.UseVisualStyleBackColor = true;
            // 
            // pnch2
            // 
            this.pnch2.Controls.Add(this.lbnd2);
            this.pnch2.Controls.Add(this.l7);
            this.pnch2.Controls.Add(this.l8);
            this.pnch2.Controls.Add(this.l6);
            this.pnch2.Controls.Add(this.l5);
            this.pnch2.Controls.Add(this.rdD2);
            this.pnch2.Controls.Add(this.rdC2);
            this.pnch2.Controls.Add(this.rdB2);
            this.pnch2.Controls.Add(this.rdA2);
            this.pnch2.Location = new System.Drawing.Point(20, 190);
            this.pnch2.Name = "pnch2";
            this.pnch2.Size = new System.Drawing.Size(699, 133);
            this.pnch2.TabIndex = 2;
            // 
            // lbnd2
            // 
            this.lbnd2.BackColor = System.Drawing.Color.LightGray;
            this.lbnd2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbnd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnd2.Location = new System.Drawing.Point(0, 0);
            this.lbnd2.Multiline = true;
            this.lbnd2.Name = "lbnd2";
            this.lbnd2.Size = new System.Drawing.Size(705, 47);
            this.lbnd2.TabIndex = 15;
            // 
            // l7
            // 
            this.l7.AutoSize = true;
            this.l7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l7.Location = new System.Drawing.Point(11, 100);
            this.l7.Name = "l7";
            this.l7.Size = new System.Drawing.Size(20, 20);
            this.l7.TabIndex = 13;
            this.l7.Text = "C";
            // 
            // l8
            // 
            this.l8.AutoSize = true;
            this.l8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l8.Location = new System.Drawing.Point(350, 100);
            this.l8.Name = "l8";
            this.l8.Size = new System.Drawing.Size(21, 20);
            this.l8.TabIndex = 12;
            this.l8.Text = "D";
            // 
            // l6
            // 
            this.l6.AutoSize = true;
            this.l6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l6.Location = new System.Drawing.Point(350, 50);
            this.l6.Name = "l6";
            this.l6.Size = new System.Drawing.Size(20, 20);
            this.l6.TabIndex = 11;
            this.l6.Text = "B";
            // 
            // l5
            // 
            this.l5.AutoSize = true;
            this.l5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l5.Location = new System.Drawing.Point(10, 50);
            this.l5.Name = "l5";
            this.l5.Size = new System.Drawing.Size(20, 20);
            this.l5.TabIndex = 10;
            this.l5.Text = "A";
            // 
            // rdD2
            // 
            this.rdD2.AutoSize = true;
            this.rdD2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdD2.Location = new System.Drawing.Point(376, 100);
            this.rdD2.Name = "rdD2";
            this.rdD2.Size = new System.Drawing.Size(83, 20);
            this.rdD2.TabIndex = 4;
            this.rdD2.TabStop = true;
            this.rdD2.Text = "Đáp Án D";
            this.rdD2.UseVisualStyleBackColor = true;
            // 
            // rdC2
            // 
            this.rdC2.AutoSize = true;
            this.rdC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdC2.Location = new System.Drawing.Point(36, 97);
            this.rdC2.Name = "rdC2";
            this.rdC2.Size = new System.Drawing.Size(82, 20);
            this.rdC2.TabIndex = 3;
            this.rdC2.TabStop = true;
            this.rdC2.Text = "Đáp Án C";
            this.rdC2.UseVisualStyleBackColor = true;
            // 
            // rdB2
            // 
            this.rdB2.AutoSize = true;
            this.rdB2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdB2.Location = new System.Drawing.Point(376, 51);
            this.rdB2.Name = "rdB2";
            this.rdB2.Size = new System.Drawing.Size(82, 20);
            this.rdB2.TabIndex = 2;
            this.rdB2.TabStop = true;
            this.rdB2.Text = "Đáp Án B";
            this.rdB2.UseVisualStyleBackColor = true;
            // 
            // rdA2
            // 
            this.rdA2.AutoSize = true;
            this.rdA2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdA2.Location = new System.Drawing.Point(36, 51);
            this.rdA2.Name = "rdA2";
            this.rdA2.Size = new System.Drawing.Size(82, 20);
            this.rdA2.TabIndex = 1;
            this.rdA2.TabStop = true;
            this.rdA2.Text = "Đáp Án A";
            this.rdA2.UseVisualStyleBackColor = true;
            // 
            // pnch1
            // 
            this.pnch1.Controls.Add(this.btct);
            this.pnch1.Controls.Add(this.lbend);
            this.pnch1.Controls.Add(this.lbnd1);
            this.pnch1.Controls.Add(this.l3);
            this.pnch1.Controls.Add(this.l4);
            this.pnch1.Controls.Add(this.l2);
            this.pnch1.Controls.Add(this.l1);
            this.pnch1.Controls.Add(this.rdD1);
            this.pnch1.Controls.Add(this.rdC1);
            this.pnch1.Controls.Add(this.rdB1);
            this.pnch1.Controls.Add(this.rdA1);
            this.pnch1.Controls.Add(this.btend);
            this.pnch1.Location = new System.Drawing.Point(20, 53);
            this.pnch1.Name = "pnch1";
            this.pnch1.Size = new System.Drawing.Size(705, 120);
            this.pnch1.TabIndex = 1;
            // 
            // btct
            // 
            this.btct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.btct.FlatAppearance.BorderSize = 0;
            this.btct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btct.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btct.ForeColor = System.Drawing.SystemColors.Window;
            this.btct.Location = new System.Drawing.Point(223, 65);
            this.btct.Name = "btct";
            this.btct.Size = new System.Drawing.Size(120, 34);
            this.btct.TabIndex = 16;
            this.btct.Text = "Chi Tiết";
            this.btct.UseVisualStyleBackColor = false;
            this.btct.Click += new System.EventHandler(this.btct_Click);
            // 
            // lbend
            // 
            this.lbend.AutoSize = true;
            this.lbend.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbend.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbend.Location = new System.Drawing.Point(191, 24);
            this.lbend.Name = "lbend";
            this.lbend.Size = new System.Drawing.Size(13, 20);
            this.lbend.TabIndex = 6;
            this.lbend.Text = ".";
            // 
            // lbnd1
            // 
            this.lbnd1.BackColor = System.Drawing.Color.LightGray;
            this.lbnd1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbnd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnd1.Location = new System.Drawing.Point(0, 0);
            this.lbnd1.Multiline = true;
            this.lbnd1.Name = "lbnd1";
            this.lbnd1.Size = new System.Drawing.Size(705, 41);
            this.lbnd1.TabIndex = 14;
            // 
            // l3
            // 
            this.l3.AutoSize = true;
            this.l3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l3.Location = new System.Drawing.Point(11, 100);
            this.l3.Name = "l3";
            this.l3.Size = new System.Drawing.Size(20, 20);
            this.l3.TabIndex = 13;
            this.l3.Text = "C";
            // 
            // l4
            // 
            this.l4.AutoSize = true;
            this.l4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l4.Location = new System.Drawing.Point(349, 96);
            this.l4.Name = "l4";
            this.l4.Size = new System.Drawing.Size(21, 20);
            this.l4.TabIndex = 12;
            this.l4.Text = "D";
            // 
            // l2
            // 
            this.l2.AutoSize = true;
            this.l2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l2.Location = new System.Drawing.Point(349, 49);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(20, 20);
            this.l2.TabIndex = 11;
            this.l2.Text = "B";
            this.l2.Click += new System.EventHandler(this.label15_Click);
            // 
            // l1
            // 
            this.l1.AutoSize = true;
            this.l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.l1.Location = new System.Drawing.Point(10, 50);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(20, 20);
            this.l1.TabIndex = 10;
            this.l1.Text = "A";
            // 
            // rdD1
            // 
            this.rdD1.AutoSize = true;
            this.rdD1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdD1.Location = new System.Drawing.Point(376, 97);
            this.rdD1.Name = "rdD1";
            this.rdD1.Size = new System.Drawing.Size(83, 20);
            this.rdD1.TabIndex = 4;
            this.rdD1.TabStop = true;
            this.rdD1.Text = "Đáp Án D";
            this.rdD1.UseVisualStyleBackColor = true;
            // 
            // rdC1
            // 
            this.rdC1.AutoSize = true;
            this.rdC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdC1.Location = new System.Drawing.Point(36, 97);
            this.rdC1.Name = "rdC1";
            this.rdC1.Size = new System.Drawing.Size(82, 20);
            this.rdC1.TabIndex = 3;
            this.rdC1.TabStop = true;
            this.rdC1.Text = "Đáp Án C";
            this.rdC1.UseVisualStyleBackColor = true;
            // 
            // rdB1
            // 
            this.rdB1.AutoSize = true;
            this.rdB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdB1.Location = new System.Drawing.Point(376, 50);
            this.rdB1.Name = "rdB1";
            this.rdB1.Size = new System.Drawing.Size(82, 20);
            this.rdB1.TabIndex = 2;
            this.rdB1.TabStop = true;
            this.rdB1.Text = "Đáp Án B";
            this.rdB1.UseVisualStyleBackColor = true;
            // 
            // rdA1
            // 
            this.rdA1.AutoSize = true;
            this.rdA1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdA1.Location = new System.Drawing.Point(36, 50);
            this.rdA1.Name = "rdA1";
            this.rdA1.Size = new System.Drawing.Size(82, 20);
            this.rdA1.TabIndex = 1;
            this.rdA1.TabStop = true;
            this.rdA1.Text = "Đáp Án A";
            this.rdA1.UseVisualStyleBackColor = true;
            // 
            // btend
            // 
            this.btend.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.btend.FlatAppearance.BorderSize = 0;
            this.btend.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btend.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btend.ForeColor = System.Drawing.SystemColors.Window;
            this.btend.Location = new System.Drawing.Point(375, 65);
            this.btend.Name = "btend";
            this.btend.Size = new System.Drawing.Size(120, 34);
            this.btend.TabIndex = 15;
            this.btend.Text = "Quay Lại";
            this.btend.UseVisualStyleBackColor = false;
            this.btend.Click += new System.EventHandler(this.btend_Click);
            // 
            // lbcau
            // 
            this.lbcau.AutoSize = true;
            this.lbcau.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbcau.ForeColor = System.Drawing.SystemColors.Window;
            this.lbcau.Location = new System.Drawing.Point(114, 270);
            this.lbcau.Name = "lbcau";
            this.lbcau.Size = new System.Drawing.Size(24, 18);
            this.lbcau.TabIndex = 8;
            this.lbcau.Text = "25";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbtime
            // 
            this.lbtime.AutoSize = true;
            this.lbtime.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbtime.Location = new System.Drawing.Point(35, 353);
            this.lbtime.Name = "lbtime";
            this.lbtime.Size = new System.Drawing.Size(151, 39);
            this.lbtime.TabIndex = 1;
            this.lbtime.Text = "00:00:00";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(39, 197);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 18);
            this.label17.TabIndex = 2;
            this.label17.Text = "MÃ ĐỀ";
            // 
            // lbde
            // 
            this.lbde.AutoSize = true;
            this.lbde.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbde.ForeColor = System.Drawing.SystemColors.Window;
            this.lbde.Location = new System.Drawing.Point(100, 197);
            this.lbde.Name = "lbde";
            this.lbde.Size = new System.Drawing.Size(32, 18);
            this.lbde.TabIndex = 3;
            this.lbde.Text = "000";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(39, 232);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 18);
            this.label19.TabIndex = 4;
            this.label19.Text = "THỜI GIAN";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(39, 270);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(69, 18);
            this.label20.TabIndex = 5;
            this.label20.Text = "CÂU HỎI";
            // 
            // lbtg
            // 
            this.lbtg.AutoSize = true;
            this.lbtg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtg.ForeColor = System.Drawing.SystemColors.Window;
            this.lbtg.Location = new System.Drawing.Point(127, 232);
            this.lbtg.Name = "lbtg";
            this.lbtg.Size = new System.Drawing.Size(24, 18);
            this.lbtg.TabIndex = 6;
            this.lbtg.Text = "45";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.Window;
            this.label22.Location = new System.Drawing.Point(149, 232);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(36, 18);
            this.label22.TabIndex = 7;
            this.label22.Text = "phút";
            // 
            // lbten
            // 
            this.lbten.AutoSize = true;
            this.lbten.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbten.ForeColor = System.Drawing.SystemColors.Window;
            this.lbten.Location = new System.Drawing.Point(76, 163);
            this.lbten.Name = "lbten";
            this.lbten.Size = new System.Drawing.Size(32, 18);
            this.lbten.TabIndex = 10;
            this.lbten.Text = "000";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(41, 163);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(29, 18);
            this.label21.TabIndex = 9;
            this.label21.Text = "ĐỀ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::QuanLyThiTracNghiem.Properties.Resources.test;
            this.pictureBox1.Location = new System.Drawing.Point(72, 65);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(79, 76);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // ThiTrucTuyen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.ClientSize = new System.Drawing.Size(1011, 711);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbten);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.lbcau);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.lbtg);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.lbde);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.lbtime);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ThiTrucTuyen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ThiTrucTuyen";
            this.Load += new System.EventHandler(this.ThiTrucTuyen_Load);
            this.groupBox1.ResumeLayout(false);
            this.pnch4.ResumeLayout(false);
            this.pnch4.PerformLayout();
            this.pnch3.ResumeLayout(false);
            this.pnch3.PerformLayout();
            this.pnch2.ResumeLayout(false);
            this.pnch2.PerformLayout();
            this.pnch1.ResumeLayout(false);
            this.pnch1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnext;
        private System.Windows.Forms.Panel pnch4;
        private System.Windows.Forms.RadioButton rdD4;
        private System.Windows.Forms.RadioButton rdC4;
        private System.Windows.Forms.RadioButton rdB4;
        private System.Windows.Forms.RadioButton rdA4;
        private System.Windows.Forms.Panel pnch3;
        private System.Windows.Forms.RadioButton rdD3;
        private System.Windows.Forms.RadioButton rdC3;
        private System.Windows.Forms.RadioButton rdB3;
        private System.Windows.Forms.RadioButton rdA3;
        private System.Windows.Forms.Panel pnch2;
        private System.Windows.Forms.RadioButton rdD2;
        private System.Windows.Forms.RadioButton rdC2;
        private System.Windows.Forms.RadioButton rdB2;
        private System.Windows.Forms.RadioButton rdA2;
        private System.Windows.Forms.Panel pnch1;
        private System.Windows.Forms.RadioButton rdD1;
        private System.Windows.Forms.RadioButton rdC1;
        private System.Windows.Forms.RadioButton rdB1;
        private System.Windows.Forms.RadioButton rdA1;
        private System.Windows.Forms.Label l15;
        private System.Windows.Forms.Label l14;
        private System.Windows.Forms.Label l13;
        private System.Windows.Forms.Label l11;
        private System.Windows.Forms.Label l10;
        private System.Windows.Forms.Label l9;
        private System.Windows.Forms.Label l7;
        private System.Windows.Forms.Label l8;
        private System.Windows.Forms.Label l6;
        private System.Windows.Forms.Label l5;
        private System.Windows.Forms.Label l3;
        private System.Windows.Forms.Label l4;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbtime;
        private System.Windows.Forms.Label lbcau;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lbde;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lbtg;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbten;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label l16;
        private System.Windows.Forms.Label l12;
        private System.Windows.Forms.TextBox lbnd1;
        private System.Windows.Forms.TextBox lbnd4;
        private System.Windows.Forms.TextBox lbnd3;
        private System.Windows.Forms.TextBox lbnd2;
        private System.Windows.Forms.Button btend;
        private System.Windows.Forms.Label lbend;
        private System.Windows.Forms.Button btct;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}