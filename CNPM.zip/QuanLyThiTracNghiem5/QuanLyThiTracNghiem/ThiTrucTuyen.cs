﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    public partial class ThiTrucTuyen : Form
    {
        int counter = 0;
        System.Timers.Timer t;
        int h, m, s;
        String made;
        List<Cauhoi> cauhoi;
        String[] dapan;
        double kq;
        int i = 0,j = 0;
        public ThiTrucTuyen(String made)
        {
            InitializeComponent();
            rdA1.Checked = false;
            this.made = made;
            LoadThongTinDe();
        }

        private void ThiTrucTuyen_Load(object sender, EventArgs e)
        {
            btct.Hide();
            lbend.Hide();
            btend.Hide();
            LoadThongTinCauhoi();
            HienThiCauHoi();
            Timer();
        }
        public void LoadThongTinDe()
        {
            lbde.Text = made;
            string sql = "select * from DeThi where made = '" + made + "'";
            SqlDataReader r = AccessDB.accessDB.ExecuteReader(sql);
            cauhoi = new List<Cauhoi>();
            if (r.Read())
            {
                lbten.Text = r[1].ToString();
                lbtg.Text = r[2].ToString();
                lbcau.Text = r[3].ToString();
            }
            counter = 60 * (Int32.Parse(lbtg.Text));
        }
        public void LoadThongTinCauhoi()
        {
            string sql = "select * from CTCauhoi where made = '" + made + "'";
            SqlDataReader r = AccessDB.accessDB.ExecuteReader(sql);
            cauhoi = new List<Cauhoi>();
            while (r.Read())
            {
                cauhoi.Add(new Cauhoi(Int32.Parse(r[0].ToString()), r[1].ToString(), r[2].ToString(), r[3].ToString(), r[4].ToString(), r[5].ToString(), r[6].ToString()));
            }
            dapan = new String[cauhoi.Count];
            for (int i = 0; i < dapan.Length; i++)
            {
                dapan[i] = "";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            counter--;
            if (counter == 0)
                timer1.Stop();
            lbtime.Text = GetTime(counter);
            if (GetTime(counter) == "00:00:00") {
                timer1.Stop();
                i = 99;
                j = 99;
                MessageBox.Show("Bạn đã hết thời gian làm bài! nhấn next để chuyển đến kết quả.");
             }
        }


        private void btnext_Click(object sender, EventArgs e)
        {
            
            HienThiCauHoi();
            LuuDapan();
        }
        public void Timer()
        {
            timer1 = new System.Windows.Forms.Timer();
            timer1.Tick += new EventHandler(timer1_Tick);
            timer1.Interval = 1000; // 1 second
            timer1.Start();
        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public string GetTime(int Time)
        {
            int Hrs = 0; 
            int Min = 0;   
            int Sec = 0;   
            
            Sec = Time % 60;
            Min = ((Time - Sec) / 60) % 60;
            Hrs = ((Time - (Sec + (Min * 60))) / 3600) % 60;

            return Microsoft.VisualBasic.Strings.Format(Hrs, "00") + ":" +
                   Microsoft.VisualBasic.Strings.Format(Min, "00") + ":" +
                   Microsoft.VisualBasic.Strings.Format(Sec, "00");
        }

        public void HienThiCauHoi()
        {

            // cau dau
            List<Object> setNull;
            if (i < cauhoi.Count)
            {
                lbnd1.Text = "Câu " + (i + 1) + ": " + cauhoi[i].Nd;
                rdA1.Text = cauhoi[i].A;
                rdB1.Text = cauhoi[i].B;
                rdC1.Text = cauhoi[i].C;
                rdD1.Text = cauhoi[i].D;
                i++;
            }
            else { lbnd1.Text = ""; rdA1.Hide(); rdB1.Hide(); rdC1.Hide(); rdD1.Hide(); l1.Hide(); l2.Hide(); l3.Hide(); l4.Hide(); }
            if (i < cauhoi.Count)
            {
                lbnd2.Text = "Câu " + (i + 1) + ": " + cauhoi[i].Nd;
                rdA2.Text = cauhoi[i].A;
                rdB2.Text = cauhoi[i].B;
                rdC2.Text = cauhoi[i].C;
                rdD2.Text = cauhoi[i].D;
                i++;
            } else { pnch2.Hide(); }

            if (i < cauhoi.Count)
            {
                lbnd3.Text = "Câu " + (i + 1) + ": " + cauhoi[i].Nd;
                rdA3.Text = cauhoi[i].A;
                rdB3.Text = cauhoi[i].B;
                rdC3.Text = cauhoi[i].C;
                rdD3.Text = cauhoi[i].D;
                i++;
            } else { pnch3.Hide(); }
            if (i < cauhoi.Count)
            {
                lbnd4.Text = "Câu " + (i + 1) + ": " + cauhoi[i].Nd;
                rdA4.Text = cauhoi[i].A;
                rdB4.Text = cauhoi[i].B;
                rdC4.Text = cauhoi[i].C;
                rdD4.Text = cauhoi[i].D;
                i++;
            }
            else { pnch4.Hide(); }
        }

        private void btct_Click(object sender, EventArgs e)
        {
            Ketqua fkq = new Ketqua();
            fkq.Loadkq(cauhoi,dapan);
            fkq.ShowDialog();
        }

        private void btend_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void LuuDapan()
        {
            if (j < dapan.Length)
            {
                //cau1
                if (rdA1.Checked) { dapan[j] = "A"; rdA1.Checked = false; }
                else if (rdB1.Checked) { dapan[j] = "B"; rdB1.Checked = false; }
                else if (rdC1.Checked) { dapan[j] = "C"; rdC1.Checked = false; }
                else if (rdD1.Checked) { dapan[j] = "D"; rdD1.Checked = false; }
                j++;
            }
            if (j < dapan.Length)
            {
                //cau2
                if (rdA2.Checked) { dapan[j] = "A"; rdA2.Checked = false; }
                else if (rdB2.Checked) { dapan[j] = "B"; rdB2.Checked = false; }
                else if (rdC2.Checked) { dapan[j] = "C"; rdC2.Checked = false; }
                else if (rdD2.Checked) { dapan[j] = "D"; rdD2.Checked = false; }
                j++;
            }
            if (j < dapan.Length)
            {
                //cau3
                if (rdA3.Checked) { dapan[j] = "A"; rdA3.Checked = false; }
                else if (rdB3.Checked) { dapan[j] = "B"; rdB3.Checked = false; }
                else if (rdC3.Checked) { dapan[j] = "C"; rdC3.Checked = false; }
                else if (rdD3.Checked) { dapan[j] = "D"; rdD3.Checked = false; }
                j++;
            }
            if (j < dapan.Length)
            {
                //cau4
                if (rdA4.Checked) { dapan[j] = "A"; rdA4.Checked = false; }
                else if (rdB4.Checked) { dapan[j] = "B"; rdB4.Checked = false; }
                else if (rdC4.Checked) { dapan[j] = "C"; rdC4.Checked = false; }
                else if (rdD4.Checked) { dapan[j] = "D"; rdD4.Checked = false; }
                j++;
            }
            else
            {
                timer1.Stop();
                lbend.Text = "Bạn đã hoàn thành bài kiểm tra với kết quả: "+kqKiemTra();
                lbend.Show();
                btend.Show();
                btct.Show();
                Luukq();
            }
        }
        public string kqKiemTra()
        {
            kq = 0;
            for (int l = 0; l < cauhoi.Count; l++)
            {
                
                if (dapan[l] == cauhoi[l].Da.Trim())
                {
                    kq++;
                }
            }
            kq = Math.Round((kq * 10) / cauhoi.Count,2);
            return kq+ "/10 điểm";
        }
        public void Luukq()
        {
            string s = "insert Ketqua values ('" + SV.Usv.Ma.Trim() + "', '" + made + "'," + kq + ",getDate())";
            AccessDB.accessDB.ExcuteNonQuery(s);
        }
    }
}
