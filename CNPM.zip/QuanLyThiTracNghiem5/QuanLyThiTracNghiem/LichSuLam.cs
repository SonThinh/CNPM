﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    public partial class LichSuLam : Form
    {
        public LichSuLam()
        {
            InitializeComponent();
            tbsearch.Focus();
            Loadgv("%");
        }
        public void Loadgv(string dk)
        {

            string sql = "select DeThi.Tende as 'Tên đề' , ketqua.NgayThi as 'Ngày thi', ketqua.diem as Điểm from DeThi, ketqua where DeThi.Made = ketqua.Made and ketqua.MasoSV = '"+ SV.Usv.Ma+"' and DeThi.Tende like '"+dk+"'";
            gvlichsu.DataSource = AccessDB.accessDB.FillDataAdapter(sql).Tables[0];
            for (int i = 0; i < gvlichsu.ColumnCount; i++)
            {
                gvlichsu.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
        }

        private void bttk_Click(object sender, EventArgs e)
        {
            string a = tbsearch.Text + "%";
            Loadgv(a);
        }

        private void LichSuLam_Load(object sender, EventArgs e)
        {

        }
    }
}
