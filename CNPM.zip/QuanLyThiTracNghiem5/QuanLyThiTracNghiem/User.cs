﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThiTracNghiem
{
    public class User
    {
        private string ma;
        private string ten;
        private string email;
        private string khoa;
        private string gioitinh;
        private string ngaysinh;
        private string quyen;
        private string taikhoan;

        public string Ma { get => ma; set => ma = value; }
        public string Ten { get => ten; set => ten = value; }
        public string Email { get => email; set => email = value; }
        public string Khoa { get => khoa; set => khoa = value; }
        public string Gioitinh { get => gioitinh; set => gioitinh = value; }
        public string Ngaysinh { get => ngaysinh; set => ngaysinh = value; }
        public string Quyen { get => quyen; set => quyen = value; }
        public string Taikhoan { get => taikhoan; set => taikhoan = value; }

        public User(string ma, string ten, string email, string khoa, string gioitinh, string ngaysinh, string taikhoan, string quyen)
        {
            this.ma = ma;
            this.ten = ten;
            this.email = email;
            this.khoa = khoa;
            this.gioitinh = gioitinh;
            this.ngaysinh = ngaysinh;
            this.quyen = quyen;
            this.taikhoan = taikhoan;
        }
        
    }
}
