﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    public partial class Ketqua : Form
    {
        public Ketqua()
        {
            InitializeComponent();
        }

        private void Ketqua_Load(object sender, EventArgs e)
        {

        }
        public void Loadkq(List<Cauhoi> ch, String[] dapan)
        {
            string s;
            Label a;
            for (int i = 0; i < dapan.Length; i++)
            {
                a = new Label();
                a.Font = new Font("Arial", 12, FontStyle.Italic);
                string sa = dapan[i];
                a.AutoSize = true;
                if (dapan[i] == "")
                {
                    s = "Câu " + (i + 1) +" null " + ch[i].Da;
                }
                else if (ch[i].Da.Trim() == dapan[i])
                {
                    s = "Câu " + (i + 1) + " đúng " + ch[i].Da;
                }
                else 
                {
                    s = "Câu " + (i + 1) + " sai " + ch[i].Da;
                }
                a.Text = s;
                a.ForeColor = Color.White;
                flp.Controls.Add(a);
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
