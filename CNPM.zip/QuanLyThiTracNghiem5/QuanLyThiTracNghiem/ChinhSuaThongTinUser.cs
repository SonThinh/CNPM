﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    public partial class ChinhSuaThongTinUser : Form
    {
        string quyen = null;
        public ChinhSuaThongTinUser(string q)
        {
            InitializeComponent();
            quyen = q;
        }

        private void ChinhSuaThongTinUser_Load(object sender, EventArgs e)
        {
            LoadThongTin();
        }
        public void LoadThongTin()
        {
            User us=null;
            if (quyen == "gv")
            {
                us = GV.Ugv;
            }
            else us = SV.Usv;
            tbma.Text = us.Ma;
            tbt.Text = us.Ten;
            tbem.Text = us.Email;
            cbk.Text = us.Khoa.Trim();
            if (us.Gioitinh == "Nam")
                rdnam.Checked = true;
            else rdnu.Checked = true;
            dns.Text = us.Ngaysinh;
            tbtk.Text = us.Taikhoan;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string gt = (rdnam.Checked == true) ? "Nam" : "Nữ";
            string query = "Update "+quyen+" set maso = '" + tbma.Text.Trim() + "', hoten = N'" + tbt.Text.Trim() + "', Email = '" + tbem.Text.Trim() + "', makhoa = '" + cbk.Text.Trim() + "', GioiTinh = N'" + gt.Trim() + "', NgaySinh = '" + dns.Text.Trim() + "' where TK='" + Login.userTK + "'";
            int a = AccessDB.accessDB.ExcuteNonQuery(query);
            if (a > 0)
            MessageBox.Show("Saved");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string qu=null;
            if (quyen == "gv") qu = GV.Ugv.Taikhoan;
            else qu = SV.Usv.Taikhoan;
            if (tbmkm.Text == null || tbmk.Text == null || tbxnmk.Text == null) { MessageBox.Show("Chưa nhập đủ thông tin!"); }
            else
            {
                if (tbmkm.Text != tbxnmk.Text)
                {
                    MessageBox.Show("Mat khau xac nhan sai!");
                }
                else if (AccessDB.accessDB.ExecuteScalar("select count(*) from Account where TK='" + qu + "';") == 0)
                {
                    MessageBox.Show("Mat khau cu khong chinh xac");
                }
                else
                {
                    string query = "Update Account set MK = '" + tbmkm.Text.Trim() + "'where TK='" + qu + "';";
                    int a = AccessDB.accessDB.ExcuteNonQuery(query);
                    if (a > 0)
                        MessageBox.Show("Saved");
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
