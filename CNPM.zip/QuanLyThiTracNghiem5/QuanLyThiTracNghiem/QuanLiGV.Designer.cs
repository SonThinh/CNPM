﻿namespace QuanLyThiTracNghiem
{
    partial class QuanLiGV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gvtk = new System.Windows.Forms.DataGridView();
            this.Taikhoan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MK = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTK = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtms = new System.Windows.Forms.TextBox();
            this.GridGV = new System.Windows.Forms.DataGridView();
            this.Maso = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Hoten = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKhoa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gioitinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ngaysinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TK = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btsearch = new System.Windows.Forms.Button();
            this.btnew = new System.Windows.Forms.Button();
            this.btdelete = new System.Windows.Forms.Button();
            this.lbtitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gvtk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridGV)).BeginInit();
            this.SuspendLayout();
            // 
            // gvtk
            // 
            this.gvtk.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gvtk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvtk.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Taikhoan,
            this.MK});
            this.gvtk.GridColor = System.Drawing.SystemColors.ScrollBar;
            this.gvtk.Location = new System.Drawing.Point(472, 12);
            this.gvtk.Name = "gvtk";
            this.gvtk.Size = new System.Drawing.Size(476, 302);
            this.gvtk.TabIndex = 22;
            // 
            // Taikhoan
            // 
            this.Taikhoan.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Taikhoan.DataPropertyName = "TK";
            this.Taikhoan.HeaderText = "Tài khoản";
            this.Taikhoan.Name = "Taikhoan";
            this.Taikhoan.ReadOnly = true;
            // 
            // MK
            // 
            this.MK.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.MK.DataPropertyName = "MK";
            this.MK.HeaderText = "Mật khẩu";
            this.MK.Name = "MK";
            this.MK.ReadOnly = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(49, 75);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Tài khoản";
            // 
            // txtTK
            // 
            this.txtTK.Location = new System.Drawing.Point(158, 72);
            this.txtTK.Margin = new System.Windows.Forms.Padding(4);
            this.txtTK.Name = "txtTK";
            this.txtTK.Size = new System.Drawing.Size(235, 20);
            this.txtTK.TabIndex = 1;
            this.txtTK.Tag = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(49, 113);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Tên";
            // 
            // txtms
            // 
            this.txtms.Location = new System.Drawing.Point(158, 106);
            this.txtms.Margin = new System.Windows.Forms.Padding(4);
            this.txtms.Name = "txtms";
            this.txtms.Size = new System.Drawing.Size(235, 20);
            this.txtms.TabIndex = 2;
            this.txtms.Tag = "";
            // 
            // GridGV
            // 
            this.GridGV.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.GridGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Maso,
            this.Hoten,
            this.Email,
            this.MaKhoa,
            this.Gioitinh,
            this.Ngaysinh,
            this.TK});
            this.GridGV.GridColor = System.Drawing.SystemColors.ScrollBar;
            this.GridGV.Location = new System.Drawing.Point(2, 320);
            this.GridGV.Name = "GridGV";
            this.GridGV.Size = new System.Drawing.Size(956, 423);
            this.GridGV.TabIndex = 20;
            // 
            // Maso
            // 
            this.Maso.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Maso.DataPropertyName = "Maso";
            this.Maso.HeaderText = "Mã số";
            this.Maso.Name = "Maso";
            // 
            // Hoten
            // 
            this.Hoten.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Hoten.DataPropertyName = "Hoten";
            this.Hoten.HeaderText = "Họ tên";
            this.Hoten.Name = "Hoten";
            // 
            // Email
            // 
            this.Email.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Email.DataPropertyName = "Email";
            this.Email.HeaderText = "Email";
            this.Email.Name = "Email";
            // 
            // MaKhoa
            // 
            this.MaKhoa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.MaKhoa.DataPropertyName = "MaKhoa";
            this.MaKhoa.HeaderText = "Mã khoa";
            this.MaKhoa.Name = "MaKhoa";
            // 
            // Gioitinh
            // 
            this.Gioitinh.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Gioitinh.DataPropertyName = "Gioitinh";
            this.Gioitinh.HeaderText = "Giới tính";
            this.Gioitinh.Name = "Gioitinh";
            // 
            // Ngaysinh
            // 
            this.Ngaysinh.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Ngaysinh.DataPropertyName = "Ngaysinh";
            this.Ngaysinh.HeaderText = "Ngày sinh";
            this.Ngaysinh.Name = "Ngaysinh";
            // 
            // TK
            // 
            this.TK.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.TK.DataPropertyName = "TK";
            this.TK.HeaderText = "Tài khoản";
            this.TK.Name = "TK";
            // 
            // btsearch
            // 
            this.btsearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btsearch.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btsearch.Image = global::QuanLyThiTracNghiem.Properties.Resources.Find;
            this.btsearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btsearch.Location = new System.Drawing.Point(29, 188);
            this.btsearch.Name = "btsearch";
            this.btsearch.Size = new System.Drawing.Size(92, 39);
            this.btsearch.TabIndex = 91;
            this.btsearch.Tag = "";
            this.btsearch.Text = "Tìm";
            this.btsearch.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btsearch.UseVisualStyleBackColor = true;
            this.btsearch.Click += new System.EventHandler(this.btsearch_Click);
            // 
            // btnew
            // 
            this.btnew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnew.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnew.Image = global::QuanLyThiTracNghiem.Properties.Resources.add_icon;
            this.btnew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnew.Location = new System.Drawing.Point(179, 188);
            this.btnew.Name = "btnew";
            this.btnew.Size = new System.Drawing.Size(92, 39);
            this.btnew.TabIndex = 90;
            this.btnew.Tag = "";
            this.btnew.Text = "Thêm";
            this.btnew.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnew.UseVisualStyleBackColor = true;
            this.btnew.Click += new System.EventHandler(this.btnew_Click);
            // 
            // btdelete
            // 
            this.btdelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btdelete.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btdelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btdelete.ForeColor = System.Drawing.SystemColors.Window;
            this.btdelete.Image = global::QuanLyThiTracNghiem.Properties.Resources.Close_2_icon;
            this.btdelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btdelete.Location = new System.Drawing.Point(324, 188);
            this.btdelete.Name = "btdelete";
            this.btdelete.Size = new System.Drawing.Size(96, 39);
            this.btdelete.TabIndex = 89;
            this.btdelete.Text = "Xóa";
            this.btdelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btdelete.UseVisualStyleBackColor = true;
            this.btdelete.Click += new System.EventHandler(this.button4_Click);
            // 
            // lbtitle
            // 
            this.lbtitle.AutoSize = true;
            this.lbtitle.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.lbtitle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbtitle.Location = new System.Drawing.Point(154, 12);
            this.lbtitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbtitle.Name = "lbtitle";
            this.lbtitle.Size = new System.Drawing.Size(159, 24);
            this.lbtitle.TabIndex = 92;
            this.lbtitle.Text = "Quản lí giáo viên";
            // 
            // QuanLiGV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.ClientSize = new System.Drawing.Size(960, 747);
            this.Controls.Add(this.lbtitle);
            this.Controls.Add(this.btsearch);
            this.Controls.Add(this.btnew);
            this.Controls.Add(this.gvtk);
            this.Controls.Add(this.btdelete);
            this.Controls.Add(this.GridGV);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtTK);
            this.Controls.Add(this.txtms);
            this.Controls.Add(this.label1);
            this.MinimizeBox = false;
            this.Name = "QuanLiGV";
            this.Text = "QuanLiGV";
            this.Load += new System.EventHandler(this.QuanLiGV_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvtk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gvtk;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTK;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtms;
        private System.Windows.Forms.DataGridView GridGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn Taikhoan;
        private System.Windows.Forms.DataGridViewTextBoxColumn MK;
        private System.Windows.Forms.DataGridViewTextBoxColumn Maso;
        private System.Windows.Forms.DataGridViewTextBoxColumn Hoten;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKhoa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gioitinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ngaysinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn TK;
        private System.Windows.Forms.Button btdelete;
        private System.Windows.Forms.Button btnew;
        private System.Windows.Forms.Button btsearch;
        private System.Windows.Forms.Label lbtitle;
    }
}