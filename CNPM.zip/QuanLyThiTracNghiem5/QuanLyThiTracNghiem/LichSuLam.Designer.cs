﻿namespace QuanLyThiTracNghiem
{
    partial class LichSuLam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LichSuLam));
            this.gvlichsu = new System.Windows.Forms.DataGridView();
            this.tbsearch = new System.Windows.Forms.TextBox();
            this.bttk = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvlichsu)).BeginInit();
            this.SuspendLayout();
            // 
            // gvlichsu
            // 
            this.gvlichsu.AllowUserToAddRows = false;
            this.gvlichsu.AllowUserToDeleteRows = false;
            this.gvlichsu.BackgroundColor = System.Drawing.SystemColors.Window;
            this.gvlichsu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvlichsu.GridColor = System.Drawing.SystemColors.Window;
            this.gvlichsu.Location = new System.Drawing.Point(12, 123);
            this.gvlichsu.Name = "gvlichsu";
            this.gvlichsu.ReadOnly = true;
            this.gvlichsu.RowHeadersWidth = 40;
            this.gvlichsu.Size = new System.Drawing.Size(934, 576);
            this.gvlichsu.TabIndex = 1;
            // 
            // tbsearch
            // 
            this.tbsearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbsearch.Location = new System.Drawing.Point(55, 93);
            this.tbsearch.Name = "tbsearch";
            this.tbsearch.Size = new System.Drawing.Size(306, 20);
            this.tbsearch.TabIndex = 75;
            this.tbsearch.Text = "Tên đề";
            // 
            // bttk
            // 
            this.bttk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttk.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.bttk.FlatAppearance.BorderSize = 0;
            this.bttk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttk.Image = global::QuanLyThiTracNghiem.Properties.Resources.Find;
            this.bttk.Location = new System.Drawing.Point(12, 87);
            this.bttk.Name = "bttk";
            this.bttk.Size = new System.Drawing.Size(37, 30);
            this.bttk.TabIndex = 76;
            this.bttk.UseVisualStyleBackColor = true;
            this.bttk.Click += new System.EventHandler(this.bttk_Click);
            // 
            // LichSuLam
            // 
            this.AcceptButton = this.bttk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.ClientSize = new System.Drawing.Size(960, 711);
            this.Controls.Add(this.bttk);
            this.Controls.Add(this.tbsearch);
            this.Controls.Add(this.gvlichsu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LichSuLam";
            this.Text = "Lichsudalam";
            this.Load += new System.EventHandler(this.LichSuLam_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvlichsu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gvlichsu;
        private System.Windows.Forms.Button bttk;
        private System.Windows.Forms.TextBox tbsearch;
    }
}