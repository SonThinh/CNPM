﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    public partial class ChinhSuaThongTinCauHoi : Form
    {
        string made;
        string socau;
        int macau;
        string s;
        string[] tt;
        public ChinhSuaThongTinCauHoi(string s)
        {
            this.s = s;
            InitializeComponent();
        }

        private void ChinhSuaThongTinCauHoi_Load(object sender, EventArgs e)
        {
            try
            {
                tt = QuanLiDeThi.ttde.Split(' ');
                tbmacau.Text = tt[0];
                socau = tt[1];
                made = tt[2];
                if (s == "c") { 
                macau = Int32.Parse(tt[3]);
                }
            }
            catch { }
            if (s == "t") {
                tbnd.Focus();
            }
            else
            {
                LoadThongtin();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (s == "t")
            {
                if (tbnd.Text == "" || tba.Text == "" || tbb.Text == "" || tbc.Text == "" || tbd.Text == "" || cbda.Text == "")
                {
                    MessageBox.Show("Chưa nhập đủ thông tin!");
                }
                else
                {
                    string s = "insert into CTCauhoi values('" + tbnd.Text + "','" + tba.Text + "','" + tbb.Text + "','" + tbc.Text + "','" + tbd.Text + "','" + cbda.Text + "','" + made + "')";
                    int a = AccessDB.accessDB.ExcuteNonQuery(s);
                    if (a > 0)
                    {
                        s = "update Dethi set Socau = " + (Int32.Parse(socau) + 1) + " where Made = '" + tbmacau.Text + "'";
                        AccessDB.accessDB.ExcuteNonQuery(s);
                        MessageBox.Show("Saved");
                        tbnd.Text = ""; tba.Text = ""; tbb.Text = ""; tbc.Text = ""; tbd.Text = ""; cbda.Text = "";
                        cbda.SelectedItem = "";
                    }
                }
            }
            else if (s == "c")
            {
                string s = "update CTCauhoi set Noidung = '" + tbnd.Text + "',DAA = '" + tba.Text + "', DAB = '" + tbb.Text + "',DAC = '" + tbc.Text + "',DAD = '" + tbd.Text + "',DADung = '" + cbda.Text + "' where Macauhoi = " + macau;
                AccessDB.accessDB.ExcuteNonQuery(s);
                MessageBox.Show("Saved");
            }
        }
        public void LoadThongtin()
        {
            
            AccessDB d = new AccessDB();
            SqlDataReader reader = d.ExecuteReader("select * from CTCauhoi where Macauhoi = '" + tt[3] + "'");
            while (reader.Read())
            {
                tbnd.Text = reader["Noidung"].ToString();
                tba.Text = reader["DAA"].ToString();
                tbb.Text = reader["DAB"].ToString();
                tbc.Text = reader["DAC"].ToString();
                tbd.Text = reader["DAD"].ToString();
                cbda.SelectedItem = reader["DADung"].ToString().Trim();
            }
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            tbnd.Text = ""; tba.Text = ""; tbb.Text = ""; tbc.Text = ""; tbd.Text = ""; cbda.Text = "";
            this.Close();
        }

        private void cbda_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
