﻿namespace QuanLyThiTracNghiem
{
    partial class BangDiemSV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BangDiemSV));
            this.tbsearch = new System.Windows.Forms.TextBox();
            this.gvd = new System.Windows.Forms.DataGridView();
            this.bttk = new System.Windows.Forms.Button();
            this.cbdethi = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbin = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvd)).BeginInit();
            this.SuspendLayout();
            // 
            // tbsearch
            // 
            this.tbsearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbsearch.Location = new System.Drawing.Point(55, 94);
            this.tbsearch.Name = "tbsearch";
            this.tbsearch.Size = new System.Drawing.Size(306, 20);
            this.tbsearch.TabIndex = 78;
            this.tbsearch.Text = "Tên SV";
            // 
            // gvd
            // 
            this.gvd.AllowUserToAddRows = false;
            this.gvd.AllowUserToDeleteRows = false;
            this.gvd.BackgroundColor = System.Drawing.SystemColors.Window;
            this.gvd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvd.GridColor = System.Drawing.SystemColors.Window;
            this.gvd.Location = new System.Drawing.Point(12, 124);
            this.gvd.Name = "gvd";
            this.gvd.ReadOnly = true;
            this.gvd.RowHeadersWidth = 40;
            this.gvd.Size = new System.Drawing.Size(934, 576);
            this.gvd.TabIndex = 77;
            // 
            // bttk
            // 
            this.bttk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bttk.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.bttk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttk.Image = global::QuanLyThiTracNghiem.Properties.Resources.Find;
            this.bttk.Location = new System.Drawing.Point(12, 88);
            this.bttk.Name = "bttk";
            this.bttk.Size = new System.Drawing.Size(37, 30);
            this.bttk.TabIndex = 79;
            this.bttk.UseVisualStyleBackColor = true;
            this.bttk.Click += new System.EventHandler(this.bttk_Click);
            // 
            // cbdethi
            // 
            this.cbdethi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbdethi.FormattingEnabled = true;
            this.cbdethi.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D"});
            this.cbdethi.Location = new System.Drawing.Point(55, 50);
            this.cbdethi.Name = "cbdethi";
            this.cbdethi.Size = new System.Drawing.Size(157, 21);
            this.cbdethi.TabIndex = 80;
            this.cbdethi.SelectedIndexChanged += new System.EventHandler(this.cbdethi_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label2.Location = new System.Drawing.Point(12, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 16);
            this.label2.TabIndex = 81;
            this.label2.Text = "Đề";
            // 
            // tbin
            // 
            this.tbin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbin.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.tbin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tbin.ForeColor = System.Drawing.SystemColors.Window;
            this.tbin.Image = global::QuanLyThiTracNghiem.Properties.Resources.print;
            this.tbin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tbin.Location = new System.Drawing.Point(634, 83);
            this.tbin.Name = "tbin";
            this.tbin.Size = new System.Drawing.Size(77, 39);
            this.tbin.TabIndex = 93;
            this.tbin.Text = "In";
            this.tbin.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tbin.UseVisualStyleBackColor = true;
            this.tbin.Click += new System.EventHandler(this.tbin_Click);
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.SystemColors.Window;
            this.button4.Image = global::QuanLyThiTracNghiem.Properties.Resources.Close_2_icon;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(503, 83);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(77, 39);
            this.button4.TabIndex = 92;
            this.button4.Text = "Xóa";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // BangDiemSV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.ClientSize = new System.Drawing.Size(960, 711);
            this.Controls.Add(this.tbin);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.cbdethi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bttk);
            this.Controls.Add(this.tbsearch);
            this.Controls.Add(this.gvd);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BangDiemSV";
            this.Text = "LichSuSV";
            ((System.ComponentModel.ISupportInitialize)(this.gvd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttk;
        private System.Windows.Forms.TextBox tbsearch;
        private System.Windows.Forms.DataGridView gvd;
        private System.Windows.Forms.ComboBox cbdethi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button tbin;
        private System.Windows.Forms.Button button4;
    }
}