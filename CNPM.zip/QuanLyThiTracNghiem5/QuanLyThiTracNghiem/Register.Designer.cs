﻿namespace QuanLyThiTracNghiem
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register));
            this.btOut = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbGen = new System.Windows.Forms.Label();
            this.lbBirth = new System.Windows.Forms.Label();
            this.lbSub = new System.Windows.Forms.Label();
            this.lbemail = new System.Windows.Forms.Label();
            this.lbName = new System.Windows.Forms.Label();
            this.lbms = new System.Windows.Forms.Label();
            this.cbSub = new System.Windows.Forms.ComboBox();
            this.cbYear = new System.Windows.Forms.ComboBox();
            this.cbMonth = new System.Windows.Forms.ComboBox();
            this.cbDate = new System.Windows.Forms.ComboBox();
            this.female = new System.Windows.Forms.RadioButton();
            this.male = new System.Windows.Forms.RadioButton();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtMS = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ckSV = new System.Windows.Forms.RadioButton();
            this.ckGV = new System.Windows.Forms.RadioButton();
            this.txtPass2 = new System.Windows.Forms.TextBox();
            this.txtPass1 = new System.Windows.Forms.TextBox();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.btRegist = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btOut
            // 
            this.btOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btOut.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btOut.FlatAppearance.BorderSize = 0;
            this.btOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btOut.ForeColor = System.Drawing.SystemColors.Window;
            this.btOut.Location = new System.Drawing.Point(654, 345);
            this.btOut.Margin = new System.Windows.Forms.Padding(4);
            this.btOut.Name = "btOut";
            this.btOut.Size = new System.Drawing.Size(136, 51);
            this.btOut.TabIndex = 20;
            this.btOut.Text = "Thoát";
            this.btOut.UseVisualStyleBackColor = false;
            this.btOut.Click += new System.EventHandler(this.btOut_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbGen);
            this.groupBox1.Controls.Add(this.lbBirth);
            this.groupBox1.Controls.Add(this.lbSub);
            this.groupBox1.Controls.Add(this.lbemail);
            this.groupBox1.Controls.Add(this.lbName);
            this.groupBox1.Controls.Add(this.lbms);
            this.groupBox1.Controls.Add(this.cbSub);
            this.groupBox1.Controls.Add(this.cbYear);
            this.groupBox1.Controls.Add(this.cbMonth);
            this.groupBox1.Controls.Add(this.cbDate);
            this.groupBox1.Controls.Add(this.female);
            this.groupBox1.Controls.Add(this.male);
            this.groupBox1.Controls.Add(this.txtEmail);
            this.groupBox1.Controls.Add(this.txtMS);
            this.groupBox1.Controls.Add(this.txtName);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Window;
            this.groupBox1.Location = new System.Drawing.Point(15, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(374, 392);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin người dùng";
            // 
            // lbGen
            // 
            this.lbGen.AutoSize = true;
            this.lbGen.ForeColor = System.Drawing.SystemColors.Window;
            this.lbGen.Location = new System.Drawing.Point(8, 351);
            this.lbGen.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbGen.Name = "lbGen";
            this.lbGen.Size = new System.Drawing.Size(57, 15);
            this.lbGen.TabIndex = 18;
            this.lbGen.Text = "Giới tính*";
            // 
            // lbBirth
            // 
            this.lbBirth.AutoSize = true;
            this.lbBirth.ForeColor = System.Drawing.SystemColors.Window;
            this.lbBirth.Location = new System.Drawing.Point(8, 284);
            this.lbBirth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbBirth.Name = "lbBirth";
            this.lbBirth.Size = new System.Drawing.Size(66, 15);
            this.lbBirth.TabIndex = 17;
            this.lbBirth.Text = "Ngày sinh*";
            // 
            // lbSub
            // 
            this.lbSub.AutoSize = true;
            this.lbSub.ForeColor = System.Drawing.SystemColors.Window;
            this.lbSub.Location = new System.Drawing.Point(4, 221);
            this.lbSub.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbSub.Name = "lbSub";
            this.lbSub.Size = new System.Drawing.Size(71, 15);
            this.lbSub.TabIndex = 16;
            this.lbSub.Text = "Chọn khoa*";
            // 
            // lbemail
            // 
            this.lbemail.AutoSize = true;
            this.lbemail.ForeColor = System.Drawing.SystemColors.Window;
            this.lbemail.Location = new System.Drawing.Point(4, 156);
            this.lbemail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbemail.Name = "lbemail";
            this.lbemail.Size = new System.Drawing.Size(115, 15);
            this.lbemail.TabIndex = 15;
            this.lbemail.Text = "Nhập địa chỉ email*";
            // 
            // lbName
            // 
            this.lbName.AutoSize = true;
            this.lbName.ForeColor = System.Drawing.SystemColors.Window;
            this.lbName.Location = new System.Drawing.Point(8, 90);
            this.lbName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(94, 15);
            this.lbName.TabIndex = 14;
            this.lbName.Text = "Nhập họ và tên*";
            // 
            // lbms
            // 
            this.lbms.AutoSize = true;
            this.lbms.ForeColor = System.Drawing.SystemColors.Window;
            this.lbms.Location = new System.Drawing.Point(8, 26);
            this.lbms.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbms.Name = "lbms";
            this.lbms.Size = new System.Drawing.Size(82, 15);
            this.lbms.TabIndex = 13;
            this.lbms.Text = "Nhập mã số *";
            // 
            // cbSub
            // 
            this.cbSub.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSub.FormattingEnabled = true;
            this.cbSub.Items.AddRange(new object[] {
            "CNTT",
            "QTKD",
            "TCNH",
            "BHLD",
            "KT"});
            this.cbSub.Location = new System.Drawing.Point(8, 249);
            this.cbSub.Margin = new System.Windows.Forms.Padding(4);
            this.cbSub.Name = "cbSub";
            this.cbSub.Size = new System.Drawing.Size(343, 23);
            this.cbSub.TabIndex = 4;
            // 
            // cbYear
            // 
            this.cbYear.FormattingEnabled = true;
            this.cbYear.Location = new System.Drawing.Point(255, 309);
            this.cbYear.Margin = new System.Windows.Forms.Padding(4);
            this.cbYear.Name = "cbYear";
            this.cbYear.Size = new System.Drawing.Size(96, 23);
            this.cbYear.TabIndex = 7;
            this.cbYear.Text = "Năm";
            // 
            // cbMonth
            // 
            this.cbMonth.FormattingEnabled = true;
            this.cbMonth.Location = new System.Drawing.Point(130, 309);
            this.cbMonth.Margin = new System.Windows.Forms.Padding(4);
            this.cbMonth.Name = "cbMonth";
            this.cbMonth.Size = new System.Drawing.Size(116, 23);
            this.cbMonth.TabIndex = 6;
            this.cbMonth.Text = "Tháng";
            // 
            // cbDate
            // 
            this.cbDate.FormattingEnabled = true;
            this.cbDate.Location = new System.Drawing.Point(10, 309);
            this.cbDate.Margin = new System.Windows.Forms.Padding(4);
            this.cbDate.Name = "cbDate";
            this.cbDate.Size = new System.Drawing.Size(109, 23);
            this.cbDate.TabIndex = 5;
            this.cbDate.Text = "Ngày";
            // 
            // female
            // 
            this.female.AutoSize = true;
            this.female.ForeColor = System.Drawing.SystemColors.Window;
            this.female.Location = new System.Drawing.Point(217, 349);
            this.female.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.female.Name = "female";
            this.female.Size = new System.Drawing.Size(41, 19);
            this.female.TabIndex = 9;
            this.female.TabStop = true;
            this.female.Text = "Nữ";
            this.female.UseVisualStyleBackColor = true;
            // 
            // male
            // 
            this.male.AutoSize = true;
            this.male.ForeColor = System.Drawing.SystemColors.Window;
            this.male.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.male.Location = new System.Drawing.Point(108, 349);
            this.male.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.male.Name = "male";
            this.male.Size = new System.Drawing.Size(52, 19);
            this.male.TabIndex = 8;
            this.male.TabStop = true;
            this.male.Text = "Nam";
            this.male.UseVisualStyleBackColor = true;
            // 
            // txtEmail
            // 
            this.txtEmail.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtEmail.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.txtEmail.BackColor = System.Drawing.SystemColors.Window;
            this.txtEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtEmail.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtEmail.Location = new System.Drawing.Point(8, 185);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(7);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(343, 21);
            this.txtEmail.TabIndex = 3;
            // 
            // txtMS
            // 
            this.txtMS.AutoCompleteCustomSource.AddRange(new string[] {
            "51603313",
            "516033"});
            this.txtMS.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtMS.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.txtMS.BackColor = System.Drawing.SystemColors.Window;
            this.txtMS.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMS.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtMS.Location = new System.Drawing.Point(10, 55);
            this.txtMS.Margin = new System.Windows.Forms.Padding(7);
            this.txtMS.Name = "txtMS";
            this.txtMS.Size = new System.Drawing.Size(343, 21);
            this.txtMS.TabIndex = 1;
            // 
            // txtName
            // 
            this.txtName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtName.Location = new System.Drawing.Point(8, 119);
            this.txtName.Margin = new System.Windows.Forms.Padding(7);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(343, 21);
            this.txtName.TabIndex = 2;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.ckSV);
            this.groupBox2.Controls.Add(this.ckGV);
            this.groupBox2.Controls.Add(this.txtPass2);
            this.groupBox2.Controls.Add(this.txtPass1);
            this.groupBox2.Controls.Add(this.txtUser);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.Window;
            this.groupBox2.Location = new System.Drawing.Point(438, 15);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(375, 306);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin tài khoản";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 156);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 15);
            this.label4.TabIndex = 20;
            this.label4.Text = "Xác nhận mật khẩu";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 90);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 15);
            this.label5.TabIndex = 19;
            this.label5.Text = "Mật khẩu*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 24);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 15);
            this.label6.TabIndex = 18;
            this.label6.Text = "Tài khoản*";
            // 
            // ckSV
            // 
            this.ckSV.AutoSize = true;
            this.ckSV.Location = new System.Drawing.Point(162, 241);
            this.ckSV.Margin = new System.Windows.Forms.Padding(4);
            this.ckSV.Name = "ckSV";
            this.ckSV.Size = new System.Drawing.Size(75, 19);
            this.ckSV.TabIndex = 14;
            this.ckSV.TabStop = true;
            this.ckSV.Text = "Sinh viên";
            this.ckSV.UseVisualStyleBackColor = true;
            // 
            // ckGV
            // 
            this.ckGV.AutoSize = true;
            this.ckGV.Location = new System.Drawing.Point(8, 241);
            this.ckGV.Margin = new System.Windows.Forms.Padding(4);
            this.ckGV.Name = "ckGV";
            this.ckGV.Size = new System.Drawing.Size(83, 19);
            this.ckGV.TabIndex = 13;
            this.ckGV.TabStop = true;
            this.ckGV.Text = "Giảng viên";
            this.ckGV.UseVisualStyleBackColor = true;
            // 
            // txtPass2
            // 
            this.txtPass2.BackColor = System.Drawing.SystemColors.Window;
            this.txtPass2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtPass2.Location = new System.Drawing.Point(8, 185);
            this.txtPass2.Margin = new System.Windows.Forms.Padding(7);
            this.txtPass2.Name = "txtPass2";
            this.txtPass2.Size = new System.Drawing.Size(343, 21);
            this.txtPass2.TabIndex = 12;
            // 
            // txtPass1
            // 
            this.txtPass1.BackColor = System.Drawing.SystemColors.Window;
            this.txtPass1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtPass1.Location = new System.Drawing.Point(8, 119);
            this.txtPass1.Margin = new System.Windows.Forms.Padding(7);
            this.txtPass1.Name = "txtPass1";
            this.txtPass1.Size = new System.Drawing.Size(343, 21);
            this.txtPass1.TabIndex = 11;
            // 
            // txtUser
            // 
            this.txtUser.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtUser.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.txtUser.BackColor = System.Drawing.SystemColors.Window;
            this.txtUser.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtUser.Location = new System.Drawing.Point(8, 53);
            this.txtUser.Margin = new System.Windows.Forms.Padding(7);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(343, 21);
            this.txtUser.TabIndex = 10;
            // 
            // btRegist
            // 
            this.btRegist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.btRegist.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btRegist.FlatAppearance.BorderSize = 0;
            this.btRegist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btRegist.ForeColor = System.Drawing.SystemColors.Window;
            this.btRegist.Location = new System.Drawing.Point(445, 345);
            this.btRegist.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btRegist.Name = "btRegist";
            this.btRegist.Size = new System.Drawing.Size(137, 51);
            this.btRegist.TabIndex = 19;
            this.btRegist.Text = "Đăng ký";
            this.btRegist.UseVisualStyleBackColor = false;
            this.btRegist.Click += new System.EventHandler(this.btRegist_Click);
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.ClientSize = new System.Drawing.Size(830, 414);
            this.Controls.Add(this.btOut);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btRegist);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Register";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Register";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btOut;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbGen;
        private System.Windows.Forms.Label lbBirth;
        private System.Windows.Forms.Label lbSub;
        private System.Windows.Forms.Label lbemail;
        private System.Windows.Forms.Label lbName;
        private System.Windows.Forms.Label lbms;
        private System.Windows.Forms.ComboBox cbSub;
        private System.Windows.Forms.RadioButton female;
        private System.Windows.Forms.RadioButton male;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtMS;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton ckSV;
        private System.Windows.Forms.RadioButton ckGV;
        private System.Windows.Forms.TextBox txtPass2;
        private System.Windows.Forms.TextBox txtPass1;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Button btRegist;
        private System.Windows.Forms.ComboBox cbYear;
        private System.Windows.Forms.ComboBox cbMonth;
        private System.Windows.Forms.ComboBox cbDate;
    }
}