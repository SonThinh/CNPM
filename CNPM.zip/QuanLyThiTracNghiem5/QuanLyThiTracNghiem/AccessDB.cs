﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThiTracNghiem
{
    class AccessDB
    {
        public static AccessDB accessDB;
        public SqlConnection GetConnection()
        {
            return new SqlConnection(@"Data Source=GWYNZ\SQLEXPRESS;Initial Catalog=QLTTN;Integrated Security=True");
        }
        public int ExcuteNonQuery(string sql)
        {
            SqlConnection conn = GetConnection();
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            int c = cmd.ExecuteNonQuery();
            conn.Close();
            cmd.Dispose();
            return c;
        }
        public SqlDataReader ExecuteReader(string sql)
        {
            SqlConnection conn = GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            return reader;
        }
        public int ExecuteScalar(string sql)
        {
            SqlConnection conn = GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            Object r = cmd.ExecuteScalar();
            int k;
            if (r != null) k = Int32.Parse(r.ToString());
            else k = -1;
            conn.Close();
            return k;
        }
        public string ExecuteScalarS(string sql)
        {
            SqlConnection conn = GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            string r = (string)cmd.ExecuteScalar();
            conn.Close();
            return r;
        }
        public DataSet FillDataAdapter(string sql)
        {
            SqlConnection conn = GetConnection();
            conn.Open();
            SqlDataAdapter adt = new SqlDataAdapter(sql, conn);
            DataSet a = new DataSet();
            adt.Fill(a);
            conn.Close();
            return a;
        }
        public int InsertDataAdapter(string sql,string tencot, string[] noidung)
        {
            
            SqlConnection conn = GetConnection();
            conn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(sql, conn); // hệ thống biết bảng nào có bao nhiêu cột
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter); //Giúp adapter có thể sử dụng để tương tác, thêm sửa xóa dữ liệu.
            DataSet ds = new DataSet();
            adapter.Fill(ds); // đổ vào dataset và đặt tên table.
            string[] tc = tencot.Split('_');
            string[] nd;
            for (int i = 0; i < noidung.Length; i++)
            {
                DataRow row = ds.Tables[0].NewRow();
                nd = noidung[i].Split('_');
                for (int j = 0; j < tc.Length; j++)
                {
                    row[tc[j]] = nd[j];
                }
                ds.Tables[0].Rows.Add(row);
            }
            int a = adapter.Update(ds.Tables[0]);
            conn.Close();
            return a;
        }
    }
}
