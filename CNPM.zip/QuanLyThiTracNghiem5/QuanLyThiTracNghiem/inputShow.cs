﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    public partial class inputShow : Form
    {
        String made;
        public inputShow()
        {
            InitializeComponent();
            tbmade.Focus();
        }

        private void inputShow_Load(object sender, EventArgs e)
        {
            
        }

        private void OK_Click(object sender, EventArgs e)
        {
            made = tbmade.Text.Trim();
            int a = AccessDB.accessDB.ExecuteScalar("select count(*) from Dethi where Made = '"+made+"'");
            if (a == 1)
            {
                
                this.Close();
                //open
                new ThiTrucTuyen(made).ShowDialog();
            }
            else
            {

                this.Close();
                MessageBox.Show("Sai mã đề");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
