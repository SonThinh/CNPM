﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThiTracNghiem
{
    public partial class Login : Form
    {
        public static String userTK;
        public Login()
        {
            InitializeComponent();
        }
        public int CheckLog(string username, string password)
        {
            SqlDataReader reader = AccessDB.accessDB.ExecuteReader("select * from Account");
            while (reader.Read())
            {
                if ((reader[0].ToString() == username && reader[1].ToString() == password))
                {
                    return 1;
                }
            }
            return 0;
        }
        public int Check(String user)
        {
            SqlDataReader reader = AccessDB.accessDB.ExecuteReader("select TK,Quyen from Account");
            while (reader.Read())
            {
                string gv = "GV";
                string sv = "SV";
                if (reader[0].ToString() == user && reader[1].ToString() == "AD")
                    return 2;
                else if (reader[0].ToString() == user && reader[1].ToString() == gv)
                {
                    return 1;
                }
                else if (reader[0].ToString() == user && reader[1].ToString() == sv)
                {
                    return 0;
                }
            }
            return 0;
        }
        private void btRegister_Click(object sender, EventArgs e)
        {
            Register dk = new Register();
            this.Hide();
            dk.ShowDialog();
            this.Show();
        }
        private void btLogin_Click(object sender, EventArgs e)
        {
            if (txtUser.Text == "" || txtPass.Text == "")
            {
                MessageBox.Show("Vui lòng nhập tài khoản và mật khẩu", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (CheckLog(txtUser.Text, txtPass.Text) == 1)
            {
                if (Check(txtUser.Text) == 1)
                {
                    //MessageBox.Show("Đăng nhập GV ", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    userTK = txtUser.Text;
                    GV gv = new GV();
                    this.Hide();
                    gv.Show();
                }

                else if (Check(txtUser.Text) == 0)
                {
                    //MessageBox.Show("Đăng nhập SV", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    userTK = txtUser.Text;
                    SV sv = new SV();
                    this.Hide();
                    sv.Show();
                }
                else
                {
                    userTK = txtUser.Text;
                    Admin a = new Admin();
                    this.Hide();
                    a.Show();
                }
            }
            else
            {
                MessageBox.Show("Sai Tài khoản hoặc Mật khẩu", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtUser.Clear();
                txtPass.Clear();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {
            AccessDB.accessDB = new AccessDB();
            txtUser.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
