﻿namespace QuanLyThiTracNghiem
{
    partial class Inkq
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gvkq = new System.Windows.Forms.DataGridView();
            this.btr = new System.Windows.Forms.Button();
            this.btn = new System.Windows.Forms.Button();
            this.btp = new System.Windows.Forms.Button();
            this.lbnum = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gvkq)).BeginInit();
            this.SuspendLayout();
            // 
            // gvkq
            // 
            this.gvkq.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvkq.Location = new System.Drawing.Point(13, 13);
            this.gvkq.Name = "gvkq";
            this.gvkq.RowHeadersVisible = false;
            this.gvkq.Size = new System.Drawing.Size(935, 654);
            this.gvkq.TabIndex = 0;
            // 
            // btr
            // 
            this.btr.Location = new System.Drawing.Point(417, 676);
            this.btr.Name = "btr";
            this.btr.Size = new System.Drawing.Size(49, 23);
            this.btr.TabIndex = 1;
            this.btr.Text = "<<";
            this.btr.UseVisualStyleBackColor = true;
            // 
            // btn
            // 
            this.btn.Location = new System.Drawing.Point(513, 676);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(49, 23);
            this.btn.TabIndex = 2;
            this.btn.Text = ">>";
            this.btn.UseVisualStyleBackColor = true;
            // 
            // btp
            // 
            this.btp.Location = new System.Drawing.Point(856, 674);
            this.btp.Name = "btp";
            this.btp.Size = new System.Drawing.Size(92, 25);
            this.btp.TabIndex = 3;
            this.btp.Text = "Print";
            this.btp.UseVisualStyleBackColor = true;
            // 
            // lbnum
            // 
            this.lbnum.AutoSize = true;
            this.lbnum.Location = new System.Drawing.Point(480, 680);
            this.lbnum.Name = "lbnum";
            this.lbnum.Size = new System.Drawing.Size(27, 13);
            this.lbnum.TabIndex = 4;
            this.lbnum.Text = "num";
            // 
            // Inkq
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 711);
            this.Controls.Add(this.lbnum);
            this.Controls.Add(this.btp);
            this.Controls.Add(this.btn);
            this.Controls.Add(this.btr);
            this.Controls.Add(this.gvkq);
            this.Name = "Inkq";
            this.Text = "Inkq";
            ((System.ComponentModel.ISupportInitialize)(this.gvkq)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gvkq;
        private System.Windows.Forms.Button btr;
        private System.Windows.Forms.Button btn;
        private System.Windows.Forms.Button btp;
        private System.Windows.Forms.Label lbnum;
    }
}