﻿create database QLTTN;
go
use QLTTN
go
create table Account(
	TK varchar(20) not null,
	MK varchar(20) not null,	
	Quyen nvarchar(10) check (Quyen='GV' OR Quyen='SV' OR Quyen='AD'),
	primary key(TK),
)
go
insert into Account values ('admin','admin','AD')
go
create table Khoa(
	MaKhoa char(10) Primary key,
	TenKhoa nvarchar(20) NOT NULL,
)
go
insert into Khoa values ('CNTT',N'Công Nghệ Thông Tin'),
						('QTKD',N'Quản trị kinh doanh'),
						('TCNH',N'Tài chính ngân hàng')
go
create table GV(
	Maso char(20) primary key NOT NULL,
	Hoten nvarchar(40) NOT NULL,
	Email varchar(100) NOT NULL,
	MaKhoa char(10) NOT NULL,
	Gioitinh nvarchar(3) NOT NULL check(Gioitinh= N'Nam' or Gioitinh= N'Nữ'),
	Ngaysinh datetime NOT NULL,
	TK varchar(20),
	constraint fk_gv_k foreign key (MaKhoa) references Khoa(MaKhoa),
	constraint fk_gv_a foreign key (TK) references Account(TK)
)
go

create table SV(
	Maso char(20) primary key NOT NULL,
	Hoten nvarchar(40) NOT NULL,
	Email varchar(100) NOT NULL,
	MaKhoa char(10) NOT NULL,
	Gioitinh nvarchar(3) NOT NULL check(Gioitinh= N'Nam' or Gioitinh= N'Nữ'),
	Ngaysinh datetime NOT NULL,
	TK varchar(20),
	constraint fk_sv_k foreign key (MaKhoa) references Khoa(MaKhoa),
	constraint fk_sv_a foreign key (TK) references Account(TK)
)
go
create table DeThi(
	Made varchar(20) primary key,
	Tende nvarchar(20),
	thoigianlam int,
	Socau int default 0
)
go
create table CTCauhoi(
	Macauhoi int IDENTITY(1,1) primary key,
	Noidung nvarchar(200),
	DAA nvarchar(50),
	DAB nvarchar(50),
	DAC nvarchar(50),
	DAD nvarchar(50),
	DADung char(5),
	Made varchar(20),
	constraint fk_ch_dt foreign key (Made) references DeThi(Made)
)

go
create table ketqua(
	Makq int IDENTITY(1,1) primary key,
	MasoSV char(20) Not Null,
	Made varchar(20),
	diem float,
	NgayThi date,
	constraint fk_kq_sv foreign key (MasoSV) references SV(Maso),
	constraint fk_kq_dt foreign key (Made) references Dethi(Made)
);